package studio.spark.duels.gui;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import studio.spark.duels.SparkDuels;
import studio.spark.duels.model.Mode;
import studio.spark.duels.util.Gui;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Mode-selection menu shown to the duel sender. */
public class DuelMenu implements InventoryHolder {

    private final UUID target;
    private final Map<Integer, String> slotMode = new HashMap<>();
    private Inventory inventory;

    private DuelMenu(UUID target) { this.target = target; }

    public UUID target() { return target; }
    public Map<Integer, String> slotMode() { return slotMode; }

    @Override
    public Inventory getInventory() { return inventory; }

    public static void open(SparkDuels plugin, Player sender, Player target) {
        DuelMenu menu = new DuelMenu(target.getUniqueId());
        List<Mode> modes = plugin.modes().duelModes();
        int size = Gui.sizeFor(modes.size());
        Inventory inv = Bukkit.createInventory(menu, size, plugin.msg().parse(plugin.msg().raw("duel.menu-title")));
        menu.inventory = inv;

        Gui.border(inv, Gui.pane(Material.GRAY_STAINED_GLASS_PANE));
        Gui.corners(inv, Gui.pane(Material.LIME_STAINED_GLASS_PANE));

        int[] slots = Gui.centered(modes.size(), size);
        for (int i = 0; i < modes.size() && i < slots.length; i++) {
            Mode m = modes.get(i);
            ItemStack icon = new ItemStack(m.icon());
            ItemMeta meta = icon.getItemMeta();
            meta.displayName(plugin.msg().item(m.display()));
            meta.lore(List.of(
                    plugin.msg().item("<gray>ᴋɪᴛ: <white>" + m.kit()),
                    plugin.msg().item(""),
                    plugin.msg().item("<#3CFF7E>\u25B6 ᴄʟɪᴄᴋ ᴛᴏ ᴄʜᴀʟʟᴇɴɢᴇ")));
            icon.setItemMeta(meta);
            inv.setItem(slots[i], icon);
            menu.slotMode.put(slots[i], m.id());
        }
        Gui.fillEmpty(inv, Gui.pane(Material.BLACK_STAINED_GLASS_PANE));
        sender.openInventory(inv);
        plugin.sounds().play(sender, "gui-open");
    }
}
