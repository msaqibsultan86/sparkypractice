package studio.spark.duels.listeners;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import studio.spark.duels.SparkDuels;
import studio.spark.duels.gui.FFAMenu;
import studio.spark.duels.gui.LeaderboardMenu;
import studio.spark.duels.gui.PartyMenu;
import studio.spark.duels.gui.QueueMenu;
import studio.spark.duels.model.Mode;

public class LobbyItemListener implements Listener {

    private final SparkDuels plugin;

    public LobbyItemListener(SparkDuels plugin) { this.plugin = plugin; }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        Player p = e.getPlayer();
        String action = plugin.lobbyItems().actionOf(e.getItem());
        if (action == null) return;
        e.setCancelled(true);

        switch (action) {
            case "q:u" -> QueueMenu.open(plugin, p, false);
            case "q:r" -> QueueMenu.open(plugin, p, true);
            case "ffa" -> FFAMenu.open(plugin, p);
            case "top" -> LeaderboardMenu.open(plugin, p, false);
            case "leave-queue" -> plugin.queue().leave(p, true);
            case "party" -> {
                if (plugin.parties().inParty(p)) PartyMenu.open(plugin, p);
                else { plugin.parties().create(p); plugin.lobbyItems().give(p); }
            }
            case "p:menu" -> PartyMenu.open(plugin, p);
            case "p:duel" -> plugin.parties().startDuel(p, firstDuel());
            case "p:ffa" -> plugin.parties().startFfa(p, firstFfa());
            case "p:leave" -> { plugin.parties().leave(p); plugin.lobbyItems().give(p); }
            default -> { }
        }
    }

    private String firstDuel() {
        return plugin.modes().duelModes().stream().findFirst().map(Mode::id).orElse("");
    }

    private String firstFfa() {
        return plugin.modes().all().stream().filter(Mode::ffa).findFirst().map(Mode::id).orElse("");
    }
}
