package studio.spark.duels.tab;

import net.kyori.adventure.text.Component;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import studio.spark.duels.SparkDuels;
import studio.spark.duels.util.Ctx;

import java.io.File;
import java.util.List;

/** Branded tablist header/footer + per-player name format. */
public class TabManager {

    private final SparkDuels plugin;
    private boolean enabled = true;
    private int updateTicks = 20;
    private List<String> header, footer;
    private String nameFormat;

    public TabManager(SparkDuels plugin) {
        this.plugin = plugin;
        load();
    }

    public void load() {
        File f = new File(plugin.getDataFolder(), "tab.yml");
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(f);
        enabled = cfg.getBoolean("enabled", true);
        updateTicks = Math.max(5, cfg.getInt("update-ticks", 20));
        header = cfg.getStringList("header");
        footer = cfg.getStringList("footer");
        nameFormat = cfg.getString("name-format", "<white>%player%");
    }

    public boolean enabled() { return enabled; }
    public int updateTicks() { return updateTicks; }

    public void tick() {
        if (!enabled) return;
        for (Player p : plugin.getServer().getOnlinePlayers()) {
            p.sendPlayerListHeaderAndFooter(build(header, p), build(footer, p));
            if (nameFormat != null && !nameFormat.isEmpty()) {
                p.playerListName(plugin.msg().parse(plugin.placeholders().apply(nameFormat, p, Ctx.of())));
            }
        }
    }

    private Component build(List<String> lines, Player p) {
        Component c = Component.empty();
        if (lines == null) return c;
        for (int i = 0; i < lines.size(); i++) {
            if (i > 0) c = c.append(Component.newline());
            c = c.append(plugin.msg().parse(plugin.placeholders().apply(lines.get(i), p, Ctx.of())));
        }
        return c;
    }
}
