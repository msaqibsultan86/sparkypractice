package studio.spark.duels.commands;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import studio.spark.duels.SparkDuels;
import studio.spark.duels.arena.Arena;
import studio.spark.duels.gui.DuelMenu;
import studio.spark.duels.kit.Kit;
import studio.spark.duels.model.Mode;
import studio.spark.duels.stats.PlayerStats;
import studio.spark.duels.util.Ctx;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public class Commands implements CommandExecutor, TabCompleter {

    private final SparkDuels plugin;

    public Commands(SparkDuels plugin) { this.plugin = plugin; }

    private Player pl(CommandSender s) { return (s instanceof Player p) ? p : null; }
    private void soon(CommandSender s) {
        plugin.msg().sendRaw(s, plugin.msg().prefix() + "<gray>ᴄᴏᴍɪɴɢ sᴏᴏɴ <dark_gray>(ᴘʜᴀsᴇ 3)", Ctx.of());
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] a) {
        String cmd = command.getName().toLowerCase(Locale.ROOT);
        Player p = pl(sender);

        switch (cmd) {
            case "duel" -> duel(sender, p, a);
            case "queue" -> {
                if (p == null) return true;
                if (a.length < 1) { plugin.msg().send(p, "queue.invalid-mode", Ctx.of().put("duel_mode", "?")); return true; }
                if (a[0].equalsIgnoreCase("leave")) plugin.queue().leave(p, true);
                else plugin.queue().join(p, a[0]);
            }
            case "stats" -> stats(sender, p, a);
            case "party" -> party(sender, p, a);
            case "kit" -> kit(sender, p, a);
            case "modekit" -> modekit(sender, a);
            case "setlobby" -> {
                if (p == null) { plugin.msg().send(sender, "general.players-only"); return true; }
                plugin.lobby().setSpawn(p.getLocation());
                plugin.msg().send(p, "lobby.set", Ctx.of().put("size", plugin.lobby().size()));
            }
            case "arena" -> arena(sender, p, a);
            case "spos1", "spos2", "scorner1", "scorner2" -> arenaPoint(sender, p, cmd);
            case "sparkpractice" -> admin(sender, a);
            case "leaderboard" -> {
                if (p == null) { plugin.msg().send(sender, "general.players-only"); return true; }
                leaderboard(p, a);
            }
            case "togglescoreboard" -> {
                if (p == null) { plugin.msg().send(sender, "general.players-only"); return true; }
                boolean shown = plugin.boards().toggle(p);
                plugin.msg().send(p, shown ? "scoreboard.shown" : "scoreboard.hidden");
            }
            case "spectate" -> {
                if (p == null) { plugin.msg().send(sender, "general.players-only"); return true; }
                if (a.length == 0 || a[0].equalsIgnoreCase("leave") || a[0].equalsIgnoreCase("stop")) {
                    plugin.spectators().leave(p);
                } else {
                    plugin.spectators().spectate(p, Bukkit.getPlayerExact(a[0]));
                }
            }
            case "rematch" -> {
                if (p == null) { plugin.msg().send(sender, "general.players-only"); return true; }
                plugin.rematches().rematch(p);
            }
            case "hallofshame" -> {
                if (p == null) { plugin.msg().send(sender, "general.players-only"); return true; }
                hallOfShame(p, a);
            }
            case "sptools" -> {
                if (p == null) { plugin.msg().send(sender, "general.players-only"); return true; }
                plugin.setupTools().give(p);
                plugin.msg().sendRaw(p, plugin.msg().prefix() + "<#3CFF7E>ɢᴀᴠᴇ ʏᴏᴜ ᴛʜᴇ sᴇᴛᴜᴘ ᴛᴏᴏʟs. <gray>ᴄʀᴇᴀᴛᴇ ᴀɴ ᴀʀᴇɴᴀ, ᴛʜᴇɴ ʀɪɢʜᴛ-ᴄʟɪᴄᴋ ᴇᴀᴄʜ ᴛᴏᴏʟ ᴡʜᴇʀᴇ ʏᴏᴜ sᴛᴀɴᴅ.", Ctx.of());
                plugin.sounds().play(p, "gui-open");
            }
            case "splaceholders" -> {
                if (p == null) { plugin.msg().send(sender, "general.players-only"); return true; }
                splaceholders(p);
            }
            case "ffa" -> ffa(sender, p, a);
            case "ffarena" -> ffarena(sender, p, a);
            case "kiteditor" -> {
                if (p == null) { plugin.msg().send(sender, "general.players-only"); return true; }
                plugin.playerKitEditor().openMenu(p);
            }
            case "kiteditorarea" -> {
                if (p == null) { plugin.msg().send(sender, "general.players-only"); return true; }
                kiteditorarea(p, a);
            }
            case "spduplicate" -> {
                if (p == null) { plugin.msg().send(sender, "general.players-only"); return true; }
                if (a.length < 1) { plugin.msg().send(p, "arena.not-found", Ctx.of().put("arena", "?")); return true; }
                plugin.dup().copy(p, a[0]);
            }
            case "sparena" -> {
                if (p == null) { plugin.msg().send(sender, "general.players-only"); return true; }
                if (a.length >= 2 && a[0].equalsIgnoreCase("paste")) plugin.dup().paste(p, a[1]);
                else plugin.msg().send(p, "arena.no-clipboard");
            }
            default -> { return false; }
        }
        return true;
    }

    private void duel(CommandSender sender, Player p, String[] a) {
        if (p == null) return;
        if (a.length == 0) { plugin.msg().send(p, "general.unknown-command"); return; }
        String sub = a[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "accept", "deny" -> {
                if (a.length < 2) { plugin.msg().send(p, "duel.no-request"); return; }
                Player other = Bukkit.getPlayerExact(a[1]);
                if (other == null) { plugin.msg().send(p, "general.player-not-found", Ctx.of().put("target", a[1])); return; }
                if (sub.equals("accept")) plugin.duels().accept(p, other);
                else plugin.duels().deny(p, other);
            }
            case "leave" -> {
                if (plugin.matches().isInMatch(p)) { plugin.matches().handleLeave(p); plugin.msg().send(p, "duel.left"); }
                else if (plugin.queue().isQueued(p)) plugin.queue().leave(p, true);
                else plugin.msg().send(p, "queue.not-queued");
            }
            case "top" -> studio.spark.duels.gui.LeaderboardMenu.open(plugin, p, false);
            default -> {
                Player target = Bukkit.getPlayerExact(a[0]);
                if (target == null) { plugin.msg().send(p, "general.player-not-found", Ctx.of().put("target", a[0])); return; }
                if (target.equals(p)) { plugin.msg().send(p, "duel.self"); return; }
                DuelMenu.open(plugin, p, target);
            }
        }
    }

    private void top(Player p, boolean ffa) {
        plugin.msg().sendRaw(p, "<gradient:#3CFF7E:#11A65B><bold>⚔ ᴛᴏᴘ ᴘʟᴀʏᴇʀs</bold></gradient>", Ctx.of());
        int rank = 1;
        for (Map.Entry<UUID, PlayerStats> e : plugin.stats().top(10, ffa)) {
            OfflinePlayer op = Bukkit.getOfflinePlayer(e.getKey());
            String name = op.getName() == null ? "?" : op.getName();
            int val = ffa ? e.getValue().ffaKills : e.getValue().wins;
            plugin.msg().sendRaw(p, "<gray>#" + rank + " <white>" + name + " <dark_gray>- <#3CFF7E>" + val, Ctx.of());
            rank++;
        }
    }

    private void stats(CommandSender sender, Player p, String[] a) {
        OfflinePlayer target;
        if (a.length >= 1) target = Bukkit.getOfflinePlayer(a[0]);
        else if (p != null) target = p;
        else { plugin.msg().send(sender, "general.players-only"); return; }

        PlayerStats s = plugin.stats().get(target.getUniqueId());
        Ctx ctx = Ctx.of()
                .put("target", target.getName() == null ? "?" : target.getName())
                .put("wins", s.wins).put("losses", s.losses).put("winrate", s.winrate())
                .put("kills", s.kills).put("deaths", s.deaths).put("kdr", String.format("%.2f", s.kdr()))
                .put("streak", s.streak).put("best_streak", s.bestStreak)
                .put("elo", s.elo).put("coins", s.coins);
        plugin.msg().sendRaw(sender, plugin.msg().raw("stats.header"), ctx);
        plugin.msg().sendRaw(sender, plugin.msg().raw("stats.line-record"), ctx);
        plugin.msg().sendRaw(sender, plugin.msg().raw("stats.line-combat"), ctx);
        plugin.msg().sendRaw(sender, plugin.msg().raw("stats.line-streak"), ctx);
        plugin.msg().sendRaw(sender, plugin.msg().raw("stats.line-elo"), ctx);
    }

    private void party(CommandSender sender, Player p, String[] a) {
        if (p == null) return;
        if (a.length < 1) { plugin.msg().send(p, "party.not-in-party"); return; }
        String sub = a[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "create" -> plugin.parties().create(p);
            case "leave" -> plugin.parties().leave(p);
            case "disband" -> plugin.parties().disband(p);
            case "list" -> plugin.parties().list(p);
            case "chat" -> {
                if (a.length < 2) return;
                plugin.parties().chat(p, String.join(" ", java.util.Arrays.copyOfRange(a, 1, a.length)));
            }
            case "invite", "accept", "deny", "kick" -> {
                if (a.length < 2) { plugin.msg().send(p, "general.player-not-found", Ctx.of().put("target", "?")); return; }
                Player t = Bukkit.getPlayerExact(a[1]);
                if (t == null) { plugin.msg().send(p, "general.player-not-found", Ctx.of().put("target", a[1])); return; }
                switch (sub) {
                    case "invite" -> plugin.parties().invite(p, t);
                    case "accept" -> plugin.parties().accept(p, t);
                    case "deny" -> plugin.parties().deny(p, t);
                    case "kick" -> plugin.parties().kick(p, t);
                }
            }
            case "duel" -> plugin.parties().startDuel(p, a.length >= 2 ? a[1] : firstDuelMode());
            case "ffa" -> plugin.parties().startFfa(p, a.length >= 2 ? a[1] : firstFfaMode());
            case "menu" -> studio.spark.duels.gui.PartyMenu.open(plugin, p);
            case "challenge" -> {
                if (a.length < 2) { plugin.msg().send(p, "general.player-not-found", Ctx.of().put("target", "?")); return; }
                Player t = Bukkit.getPlayerExact(a[1]);
                if (t == null) { plugin.msg().send(p, "general.player-not-found", Ctx.of().put("target", a[1])); return; }
                plugin.parties().challenge(p, t, a.length >= 3 ? a[2] : firstDuelMode());
            }
            case "caccept" -> plugin.parties().acceptChallenge(p);
            case "cdeny" -> plugin.parties().denyChallenge(p);
            default -> plugin.msg().send(p, "party.not-in-party");
        }
    }

    private void kit(CommandSender sender, Player p, String[] a) {
        if (a.length < 1) { plugin.msg().send(sender, "kit.list", Ctx.of().put("count", 0).put("list", "")); return; }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "list" -> {
                var kits = plugin.kits().all();
                StringBuilder sb = new StringBuilder();
                boolean first = true;
                for (Kit k : kits) {
                    if (!first) sb.append("<dark_gray>, ");
                    first = false;
                    sb.append(kitHoverName(k));
                }
                plugin.msg().sendRaw(sender, plugin.msg().prefix()
                        + "<gray>ᴋɪᴛs <dark_gray>(" + kits.size() + ")<gray>: " + sb, Ctx.of());
            }
            case "give" -> {
                if (!sender.hasPermission("sparkpractice.kit.admin")) { plugin.msg().send(sender, "general.no-permission"); return; }
                if (a.length < 3) { plugin.msg().send(sender, "kit.not-found", Ctx.of().put("kit", "?")); return; }
                Player t = Bukkit.getPlayerExact(a[1]);
                Kit kit = plugin.kits().get(a[2]);
                if (t == null) { plugin.msg().send(sender, "general.player-not-found", Ctx.of().put("target", a[1])); return; }
                if (kit == null) { plugin.msg().send(sender, "kit.not-found", Ctx.of().put("kit", a[2])); return; }
                kit.apply(t);
                plugin.msg().send(sender, "kit.given", Ctx.of().put("kit", kit.name()).target(t));
            }
            case "preview" -> {
                if (p == null) { plugin.msg().send(sender, "general.players-only"); return; }
                if (a.length < 2) { plugin.msg().send(p, "kit.not-found", Ctx.of().put("kit", "?")); return; }
                Kit kit = plugin.kits().get(a[1]);
                if (kit == null) { plugin.msg().send(p, "kit.not-found", Ctx.of().put("kit", a[1])); return; }
                Inventory inv = Bukkit.createInventory(null, 54,
                        plugin.msg().parse("<gradient:#3CFF7E:#11A65B>" + kit.name() + "</gradient>"));
                ItemStack[] c = kit.contents();
                for (int i = 0; i < 36 && i < c.length; i++) if (c[i] != null) inv.setItem(i, c[i].clone());
                if (kit.helmet() != null) inv.setItem(45, kit.helmet().clone());
                if (kit.chestplate() != null) inv.setItem(46, kit.chestplate().clone());
                if (kit.leggings() != null) inv.setItem(47, kit.leggings().clone());
                if (kit.boots() != null) inv.setItem(48, kit.boots().clone());
                if (kit.offhand() != null) inv.setItem(49, kit.offhand().clone());
                p.openInventory(inv);
                plugin.sounds().play(p, "gui-open");
            }
            case "create" -> {
                if (!sender.hasPermission("sparkpractice.kit.admin")) { plugin.msg().send(sender, "general.no-permission"); return; }
                if (p == null) { plugin.msg().send(sender, "general.players-only"); return; }
                if (a.length < 2) { plugin.msg().send(p, "kit.not-found", Ctx.of().put("kit", "?")); return; }
                plugin.kitEditor().createFromInventory(p, a[1]);
            }
            case "delete" -> {
                if (!sender.hasPermission("sparkpractice.kit.admin")) { plugin.msg().send(sender, "general.no-permission"); return; }
                if (a.length < 2) { plugin.msg().send(sender, "kit.not-found", Ctx.of().put("kit", "?")); return; }
                boolean ok = plugin.kitSerializer().deleteKit(a[1]);
                plugin.msg().send(sender, ok ? "kit.deleted" : "kit.not-found", Ctx.of().put("kit", a[1]));
            }
            default -> plugin.msg().send(sender, "kit.list", Ctx.of().put("count", plugin.kits().all().size()).put("list", ""));
        }
    }

    private void modekit(CommandSender sender, String[] a) {
        if (a.length < 2) { plugin.msg().send(sender, "kit.not-found", Ctx.of().put("kit", "?")); return; }
        Mode mode = plugin.modes().get(a[0]);
        Kit kit = plugin.kits().get(a[1]);
        if (mode == null) { plugin.msg().send(sender, "queue.invalid-mode", Ctx.of().put("duel_mode", a[0])); return; }
        if (kit == null) { plugin.msg().send(sender, "kit.not-found", Ctx.of().put("kit", a[1])); return; }
        plugin.modesConfig().set("modes." + mode.id() + ".kit", kit.name());
        plugin.saveModesConfig();
        plugin.modes().load();
        plugin.msg().send(sender, "kit.linked", Ctx.of().put("kit", kit.name()).put("duel_mode", mode.display()));
    }

    private void arena(CommandSender sender, Player p, String[] a) {
        if (a.length < 1) { plugin.msg().send(sender, "arena.no-setup"); return; }
        String sub = a[0].toLowerCase(Locale.ROOT);
        if (sub.equals("list")) {
            List<String> names = new ArrayList<>();
            plugin.arenas().all().forEach(ar -> names.add(ar.name() + (ar.isComplete() ? "" : "*")));
            plugin.msg().send(sender, "arena.list", Ctx.of().put("list", names.isEmpty() ? "none" : String.join(", ", names)));
            return;
        }
        if (a.length < 2) { plugin.msg().send(sender, "arena.not-found", Ctx.of().put("arena", "?")); return; }
        String name = a[1];
        switch (sub) {
            case "create" -> {
                if (p == null) { plugin.msg().send(sender, "general.players-only"); return; }
                plugin.arenas().create(name);
                plugin.arenas().beginSetup(p.getUniqueId(), name);
                plugin.msg().send(p, "arena.setup-started", Ctx.of().put("arena", name));
            }
            case "delete" -> {
                boolean ok = plugin.arenas().delete(name);
                plugin.msg().send(sender, ok ? "arena.deleted" : "arena.not-found", Ctx.of().put("arena", name));
            }
            case "enable", "disable" -> {
                Arena ar = plugin.arenas().get(name);
                if (ar == null) { plugin.msg().send(sender, "arena.not-found", Ctx.of().put("arena", name)); return; }
                ar.enabled(sub.equals("enable"));
                plugin.arenas().save();
                plugin.msg().send(sender, sub.equals("enable") ? "arena.enabled" : "arena.disabled", Ctx.of().put("arena", name));
            }
            default -> plugin.msg().send(sender, "arena.no-setup");
        }
    }

    private void arenaPoint(CommandSender sender, Player p, String cmd) {
        if (p == null) { plugin.msg().send(sender, "general.players-only"); return; }
        Arena ar = plugin.arenas().currentSetup(p.getUniqueId());
        if (ar == null) { plugin.msg().send(p, "arena.no-setup"); return; }
        switch (cmd) {
            case "spos1" -> { ar.spawn1(p.getLocation()); plugin.arenas().save(); plugin.msg().send(p, "arena.pos1-set"); }
            case "spos2" -> { ar.spawn2(p.getLocation()); plugin.arenas().save(); plugin.msg().send(p, "arena.pos2-set"); }
            case "scorner1" -> { ar.corner1(p.getLocation()); plugin.arenas().save(); plugin.msg().send(p, "arena.corner1-set"); }
            case "scorner2" -> {
                ar.corner2(p.getLocation());
                ar.enabled(true);
                plugin.arenas().save();
                plugin.msg().send(p, "arena.corner2-set", Ctx.of().put("arena", ar.name()));
            }
        }
    }

    private void admin(CommandSender sender, String[] a) {
        if (a.length >= 1 && a[0].equalsIgnoreCase("reload")) {
            plugin.reloadAll();
            plugin.msg().send(sender, "general.reloaded");
            if (sender instanceof Player pp) plugin.sounds().play(pp, "reload");
        } else if (a.length >= 1 && a[0].equalsIgnoreCase("help")) {
            plugin.msg().sendList(sender, "help", Ctx.of());
        } else {
            plugin.msg().sendList(sender, "info", Ctx.of());
        }
    }

    private String firstDuelMode() {
        return plugin.modes().duelModes().stream().findFirst().map(Mode::id).orElse("");
    }

    private String firstFfaMode() {
        return plugin.modes().all().stream().filter(Mode::ffa).findFirst().map(Mode::id).orElse("");
    }

    private String kitHoverName(Kit k) {
        StringBuilder lore = new StringBuilder("<gradient:#3CFF7E:#11A65B>" + k.name() + "</gradient>");
        appendItem(lore, k.helmet());
        appendItem(lore, k.chestplate());
        appendItem(lore, k.leggings());
        appendItem(lore, k.boots());
        for (org.bukkit.inventory.ItemStack is : k.contents()) {
            if (lore.length() > 700) { lore.append("<newline><dark_gray>…"); break; }
            appendItem(lore, is);
        }
        return "<hover:show_text:'" + lore + "'><gradient:#3CFF7E:#11A65B>" + k.name() + "</gradient></hover>";
    }

    private void appendItem(StringBuilder sb, org.bukkit.inventory.ItemStack is) {
        if (is == null || is.getType() == org.bukkit.Material.AIR) return;
        String n = is.getType().name().toLowerCase(Locale.ROOT).replace('_', ' ').replace("'", "");
        sb.append("<newline><gray>").append(is.getAmount() > 1 ? is.getAmount() + "x " : "").append(n);
    }

    private void leaderboard(Player p, String[] a) {
        var lb = plugin.leaderboards();
        String sub = a.length >= 1 ? a[0].toLowerCase(Locale.ROOT) : "help";
        switch (sub) {
            case "summon" -> {
                if (a.length < 2) {
                    plugin.msg().sendRaw(p, plugin.msg().prefix() + "<gray>ᴜsᴀɢᴇ <white>/lb summon <type>", Ctx.of());
                    plugin.msg().sendRaw(p, "<gray>ᴛʏᴘᴇs <#3CFF7E>" + String.join("<gray>, <#3CFF7E>",
                            studio.spark.duels.leaderboard.LeaderboardHologram.TYPES), Ctx.of());
                    return;
                }
                String type = a[1].toUpperCase(Locale.ROOT);
                if (!lb.isValidType(type)) {
                    plugin.msg().sendRaw(p, plugin.msg().prefix() + "<#FC5454>ᴜɴᴋɴᴏᴡɴ ᴛʏᴘᴇ. <gray>"
                            + String.join(", ", studio.spark.duels.leaderboard.LeaderboardHologram.TYPES), Ctx.of());
                    return;
                }
                lb.summon(p, type);
                plugin.msg().sendRaw(p, plugin.msg().prefix() + "<#3CFF7E>sᴜᴍᴍᴏɴᴇᴅ <white>" + type
                        + " <#3CFF7E>ʟᴇᴀᴅᴇʀʙᴏᴀʀᴅ ʜᴇʀᴇ.", Ctx.of());
                plugin.sounds().play(p, "gui-open");
            }
            case "remove", "delete" -> {
                boolean ok = lb.removeNearest(p);
                plugin.msg().sendRaw(p, plugin.msg().prefix() + (ok
                        ? "<#3CFF7E>ʀᴇᴍᴏᴠᴇᴅ ᴛʜᴇ ɴᴇᴀʀᴇsᴛ ʟᴇᴀᴅᴇʀʙᴏᴀʀᴅ."
                        : "<#FC5454>ɴᴏ ʟᴇᴀᴅᴇʀʙᴏᴀʀᴅ ᴡɪᴛʜɪɴ 6 ʙʟᴏᴄᴋs."), Ctx.of());
            }
            case "list" -> {
                var lines = lb.listLines();
                plugin.msg().sendRaw(p, plugin.msg().prefix() + "<#3CFF7E>ʟᴇᴀᴅᴇʀʙᴏᴀʀᴅs <dark_gray>(" + lines.size() + ")", Ctx.of());
                if (lines.isEmpty()) plugin.msg().sendRaw(p, "<gray>ɴᴏɴᴇ. ᴜsᴇ <white>/lb summon <type>", Ctx.of());
                for (String l : lines) plugin.msg().sendRaw(p, "<dark_gray>• <gray>" + l, Ctx.of());
            }
            case "reload" -> {
                lb.update();
                plugin.msg().sendRaw(p, plugin.msg().prefix() + "<#3CFF7E>ʀᴇꜰʀᴇsʜᴇᴅ ᴀʟʟ ʟᴇᴀᴅᴇʀʙᴏᴀʀᴅs.", Ctx.of());
            }
            default -> {
                plugin.msg().sendRaw(p, plugin.msg().prefix() + "<#3CFF7E>ʟᴇᴀᴅᴇʀʙᴏᴀʀᴅ ʜᴏʟᴏɢʀᴀᴍs", Ctx.of());
                plugin.msg().sendRaw(p, "<gray>/lb summon <type> <dark_gray>- ᴄʀᴇᴀᴛᴇ ᴏɴᴇ ᴡʜᴇʀᴇ ʏᴏᴜ sᴛᴀɴᴅ", Ctx.of());
                plugin.msg().sendRaw(p, "<gray>/lb remove <dark_gray>- ʀᴇᴍᴏᴠᴇ ᴛʜᴇ ɴᴇᴀʀᴇsᴛ", Ctx.of());
                plugin.msg().sendRaw(p, "<gray>/lb list <dark_gray>- ʟɪsᴛ ᴀʟʟ", Ctx.of());
                plugin.msg().sendRaw(p, "<gray>ᴛʏᴘᴇs <#3CFF7E>" + String.join("<gray>, <#3CFF7E>",
                        studio.spark.duels.leaderboard.LeaderboardHologram.TYPES), Ctx.of());
            }
        }
    }

    private void hallOfShame(Player p, String[] a) {
        var hos = plugin.hallOfShame();
        String sub = a.length >= 1 ? a[0].toLowerCase(Locale.ROOT) : "help";
        switch (sub) {
            case "summon" -> {
                hos.summon(p);
                plugin.msg().sendRaw(p, plugin.msg().prefix() + "<#FC5454>sᴜᴍᴍᴏɴᴇᴅ ᴛʜᴇ ʜᴀʟʟ ᴏꜰ sʜᴀᴍᴇ ʜᴇʀᴇ.", Ctx.of());
                plugin.sounds().play(p, "gui-open");
            }
            case "remove", "delete" -> {
                hos.remove();
                plugin.msg().sendRaw(p, plugin.msg().prefix() + "<gray>ʀᴇᴍᴏᴠᴇᴅ ᴛʜᴇ ʜᴀʟʟ ᴏꜰ sʜᴀᴍᴇ ʙᴏᴀʀᴅ.", Ctx.of());
            }
            case "add" -> {
                if (a.length < 3) {
                    plugin.msg().sendRaw(p, plugin.msg().prefix() + "<gray>ᴜsᴀɢᴇ <white>/hos add <player> <reason>", Ctx.of());
                    return;
                }
                String name = a[1];
                StringBuilder r = new StringBuilder();
                for (int i = 2; i < a.length; i++) r.append(i > 2 ? " " : "").append(a[i]);
                hos.record(name, r.toString(), "BAN");
                plugin.msg().sendRaw(p, plugin.msg().prefix() + "<#FC5454>ᴀᴅᴅᴇᴅ <white>" + name + " <gray>ᴛᴏ ᴛʜᴇ ʜᴀʟʟ ᴏꜰ sʜᴀᴍᴇ.", Ctx.of());
            }
            case "clear" -> {
                hos.clear();
                plugin.msg().sendRaw(p, plugin.msg().prefix() + "<gray>ᴄʟᴇᴀʀᴇᴅ ᴀʟʟ ʜᴀʟʟ ᴏꜰ sʜᴀᴍᴇ ᴇɴᴛʀɪᴇs.", Ctx.of());
            }
            case "list" -> {
                plugin.msg().sendRaw(p, plugin.msg().prefix() + "<#FC5454>ʜᴀʟʟ ᴏꜰ sʜᴀᴍᴇ <dark_gray>(" + hos.size() + " ᴇɴᴛʀɪᴇs)", Ctx.of());
            }
            default -> {
                plugin.msg().sendRaw(p, plugin.msg().prefix() + "<#FC5454>ʜᴀʟʟ ᴏꜰ sʜᴀᴍᴇ", Ctx.of());
                plugin.msg().sendRaw(p, "<gray>/hos summon <dark_gray>- ᴘʟᴀᴄᴇ ᴛʜᴇ ʙᴏᴀʀᴅ", Ctx.of());
                plugin.msg().sendRaw(p, "<gray>/hos add <player> <reason> <dark_gray>- ᴀᴅᴅ ᴀ ᴄʜᴇᴀᴛᴇʀ (ᴇ.ɢ. ᴋɪʟʟᴀᴜʀᴀ)", Ctx.of());
                plugin.msg().sendRaw(p, "<gray>/hos remove | clear | list", Ctx.of());
                plugin.msg().sendRaw(p, "<dark_gray>ʙᴀɴs ᴀʀᴇ ʟᴏɢɢᴇᴅ ᴀᴜᴛᴏᴍᴀᴛɪᴄᴀʟʟʏ ᴡɪᴛʜ ᴛʜᴇ ʙᴀɴ ʀᴇᴀsᴏɴ.", Ctx.of());
            }
        }
    }

    private void splaceholders(Player p) {
        String[][] groups = {
            {"ꜱᴛᴀᴛs", "wins,losses,kills,deaths,kdr,winrate,elo,coins,playtime,streak,best_streak,rank,matches_played"},
            {"ꜰꜰᴀ", "ffa_kills,ffa_deaths,ffa_kdr,ffa_streak,ffa_best_streak,ffa_killstreak"},
            {"sᴇʀᴠᴇʀ", "online,lobby_total,queued_total,match_total,ffa_total,max_players,version,discord_link,modes_total,arena_total,ffa_arena_total"},
            {"ᴘʟᴀʏᴇʀ", "ping,world,state"},
            {"ǫᴜᴇᴜᴇ", "queue_mode,queue_position,queue_players,queue_wait_time"},
            {"ᴅᴜᴇʟ", "duel_mode,duel_arena,duel_opponent,duel_duration,duel_health,duel_opponent_health"},
        };
        int total = 0;
        for (String[] g : groups) total += g[1].split(",").length;

        plugin.msg().sendRaw(p, plugin.msg().prefix() + "<gradient:#3CFF7E:#11A65B><bold>ᴘʟᴀᴄᴇʜᴏʟᴅᴇʀs</bold></gradient> <dark_gray>(" + total + ")", Ctx.of());
        plugin.msg().sendRaw(p, "<gray>ᴄʟɪᴄᴋ ᴀɴʏ ᴘʟᴀᴄᴇʜᴏʟᴅᴇʀ ᴛᴏ ᴄᴏᴘʏ ɪᴛ.", Ctx.of());
        for (String[] g : groups) {
            StringBuilder line = new StringBuilder("<#FFD23C>" + g[0] + " <dark_gray>» ");
            String[] keys = g[1].split(",");
            for (int i = 0; i < keys.length; i++) {
                String ph = "%sparkpractice_" + keys[i] + "%";
                if (i > 0) line.append("<dark_gray>, ");
                line.append("<click:copy_to_clipboard:'").append(ph).append("'>")
                    .append("<hover:show_text:'<gray>ᴄʟɪᴄᴋ ᴛᴏ ᴄᴏᴘʏ<newline><white>").append(ph).append("'>")
                    .append("<#3CFF7E>").append(keys[i]).append("</hover></click>");
            }
            plugin.msg().sendRaw(p, line.toString(), Ctx.of());
        }
        plugin.sounds().play(p, "gui-open");
    }

    private void kiteditorarea(Player p, String[] a) {
        if (a.length < 1) { plugin.msg().send(p, "kiteditor.area-usage"); return; }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "build" -> {
                plugin.playerKitEditor().buildRoom(p);
            }
            case "spawn" -> {
                plugin.playerKitEditor().writeLoc("kit-editor.spawn", p.getLocation());
                plugin.msg().send(p, "kiteditor.spawn-set");
            }
            case "corner1" -> {
                plugin.playerKitEditor().writeLoc("kit-editor.corner1", p.getLocation());
                plugin.msg().send(p, "kiteditor.corner1-set");
            }
            case "corner2" -> {
                plugin.playerKitEditor().writeLoc("kit-editor.corner2", p.getLocation());
                plugin.msg().send(p, "kiteditor.corner2-set");
            }
            case "npc" -> {
                plugin.playerKitEditor().writeLoc("kit-editor.npc", p.getLocation());
                plugin.playerKitEditor().spawnNpc();
                plugin.msg().send(p, "kiteditor.npc-set");
            }
            case "leavenpc" -> {
                plugin.playerKitEditor().writeLoc("kit-editor.leave-npc", p.getLocation());
                plugin.playerKitEditor().spawnNpc();
                plugin.msg().sendRaw(p, plugin.msg().prefix() + "<#3CFF7E>ʟᴇᴀᴠᴇ ɴᴘᴄ sᴇᴛ.", Ctx.of());
            }
            case "info" -> {
                String s = "<gray>sᴘᴀᴡɴ: " + (plugin.playerKitEditor().spawn() != null ? "<#3CFF7E>✔" : "<red>✖")
                        + " <gray>ᴄᴏʀɴᴇʀ1: " + (plugin.playerKitEditor().corner1() != null ? "<#3CFF7E>✔" : "<red>✖")
                        + " <gray>ᴄᴏʀɴᴇʀ2: " + (plugin.playerKitEditor().corner2() != null ? "<#3CFF7E>✔" : "<red>✖")
                        + " <gray>ɴᴘᴄ: " + (plugin.getConfig().contains("kit-editor.npc") ? "<#3CFF7E>✔" : "<red>✖");
                plugin.msg().sendRaw(p, plugin.msg().prefix() + s, Ctx.of());
            }
            default -> plugin.msg().send(p, "kiteditor.area-usage");
        }
    }

    private void ffa(CommandSender sender, Player p, String[] a) {
        if (p == null) { plugin.msg().send(sender, "general.players-only"); return; }
        if (a.length < 1) { plugin.msg().send(p, "ffa.invalid-mode", Ctx.of().put("ffa_mode", "?")); return; }
        switch (a[0].toLowerCase(Locale.ROOT)) {
            case "leave" -> plugin.ffa().leave(p);
            case "top" -> studio.spark.duels.gui.LeaderboardMenu.open(plugin, p, true);
            default -> plugin.ffa().join(p, a[0]);
        }
    }

    private void ffarena(CommandSender sender, Player p, String[] a) {
        if (a.length < 1) { plugin.msg().send(sender, "arena.no-setup"); return; }
        String sub = a[0].toLowerCase(Locale.ROOT);
        if (sub.equals("list")) {
            List<String> names = new ArrayList<>();
            plugin.ffa().all().forEach(ar -> names.add(ar.name() + "(" + ar.spawns().size() + ")"));
            plugin.msg().send(sender, "ffa.list", Ctx.of().put("list", names.isEmpty() ? "none" : String.join(", ", names)));
            return;
        }
        if (a.length < 2) { plugin.msg().send(sender, "ffa.arena-not-found", Ctx.of().put("arena", "?")); return; }
        String name = a[1];
        if (sub.equals("create")) {
            plugin.ffa().create(name);
            plugin.msg().send(sender, "ffa.created", Ctx.of().put("arena", name));
            return;
        }
        var arena = plugin.ffa().get(name);
        if (arena == null) { plugin.msg().send(sender, "ffa.arena-not-found", Ctx.of().put("arena", name)); return; }
        switch (sub) {
            case "addspawn" -> {
                if (p == null) { plugin.msg().send(sender, "general.players-only"); return; }
                plugin.ffa().addSpawn(arena, p.getLocation());
                plugin.msg().send(p, "ffa.spawn-added", Ctx.of().put("arena", name).put("count", arena.spawns().size()));
            }
            case "setkit" -> {
                if (a.length < 3 || plugin.kits().get(a[2]) == null) { plugin.msg().send(sender, "kit.not-found", Ctx.of().put("kit", a.length < 3 ? "?" : a[2])); return; }
                plugin.ffa().setKit(arena, plugin.kits().get(a[2]).name());
                plugin.msg().send(sender, "ffa.kit-set", Ctx.of().put("arena", name).put("kit", a[2]));
            }
            case "setmode" -> {
                Mode mode = a.length < 3 ? null : plugin.modes().get(a[2]);
                if (mode == null || !mode.ffa()) { plugin.msg().send(sender, "ffa.invalid-mode", Ctx.of().put("ffa_mode", a.length < 3 ? "?" : a[2])); return; }
                plugin.ffa().setMode(arena, mode.id());
                plugin.msg().send(sender, "ffa.mode-set", Ctx.of().put("arena", name).put("ffa_mode", mode.display()));
            }
            case "corner1" -> { if (p != null) { arena.corner1(p.getLocation()); plugin.ffa().save(); plugin.msg().send(p, "arena.corner1-set"); } }
            case "corner2" -> { if (p != null) { arena.corner2(p.getLocation()); plugin.ffa().save(); plugin.msg().send(p, "arena.corner2-set", Ctx.of().put("arena", name)); } }
            case "enable", "disable" -> {
                plugin.ffa().setEnabled(arena, sub.equals("enable"));
                plugin.msg().send(sender, sub.equals("enable") ? "ffa.enabled" : "ffa.disabled", Ctx.of().put("arena", name));
            }
            case "delete" -> { plugin.ffa().delete(name); plugin.msg().send(sender, "ffa.deleted", Ctx.of().put("arena", name)); }
            default -> plugin.msg().send(sender, "arena.no-setup");
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] a) {
        String cmd = command.getName().toLowerCase(Locale.ROOT);
        List<String> out = new ArrayList<>();
        if (cmd.equals("queue") && a.length == 1) {
            plugin.modes().duelModes().forEach(m -> out.add(m.id()));
            out.add("leave");
        } else if (cmd.equals("duel") && a.length == 1) {
            out.add("accept"); out.add("deny"); out.add("leave"); out.add("top");
            Bukkit.getOnlinePlayers().forEach(o -> out.add(o.getName()));
        } else if (cmd.equals("kit") && a.length == 1) {
            out.addAll(List.of("list", "give", "preview", "create", "delete"));
        } else if (cmd.equals("arena") && a.length == 1) {
            out.addAll(List.of("create", "list", "delete", "enable", "disable"));
        } else if (cmd.equals("party") && a.length == 1) {
            out.addAll(List.of("create", "invite", "accept", "deny", "leave", "disband", "kick", "list", "chat"));
        } else if (cmd.equals("sparkpractice") && a.length == 1) {
            out.addAll(List.of("reload", "info", "help"));
        } else if (cmd.equals("ffa") && a.length == 1) {
            plugin.modes().all().stream().filter(Mode::ffa).forEach(m -> out.add(m.id()));
            out.add("leave"); out.add("top");
        } else if (cmd.equals("ffarena") && a.length == 1) {
            out.addAll(List.of("create", "addspawn", "setkit", "setmode", "corner1", "corner2", "enable", "disable", "delete", "list"));
        } else if (cmd.equals("hallofshame") && a.length == 1) {
            out.addAll(List.of("summon", "remove", "add", "clear", "list"));
        } else if (cmd.equals("hallofshame") && a.length == 2 && a[0].equalsIgnoreCase("add")) {
            Bukkit.getOnlinePlayers().forEach(o -> out.add(o.getName()));
        } else if (cmd.equals("spectate") && a.length == 1) {
            out.add("leave");
            Bukkit.getOnlinePlayers().forEach(o -> out.add(o.getName()));
        } else if (cmd.equals("leaderboard") && a.length == 1) {
            out.addAll(List.of("summon", "remove", "list", "reload"));
        } else if (cmd.equals("leaderboard") && a.length == 2 && a[0].equalsIgnoreCase("summon")) {
            out.addAll(studio.spark.duels.leaderboard.LeaderboardHologram.TYPES);
        } else if (cmd.equals("kiteditorarea") && a.length == 1) {
            out.addAll(List.of("build", "spawn", "corner1", "corner2", "npc", "leavenpc", "info"));
        } else if ((cmd.equals("modekit")) && a.length == 1) {
            plugin.modes().all().forEach(m -> out.add(m.id()));
        } else if ((cmd.equals("modekit")) && a.length == 2) {
            plugin.kits().all().forEach(k -> out.add(k.name()));
        }
        return out;
    }
}
