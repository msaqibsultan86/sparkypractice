package studio.spark.duels.arena;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import studio.spark.duels.SparkDuels;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Lightweight arena regeneration. Records the ORIGINAL block data the first time
 * a block changes inside an in-use arena, then restores them all when the match
 * ends. Only changed blocks are stored, so it's cheap for normal practice fights.
 */
public class ArenaReset {

    private final SparkDuels plugin;
    private final Map<String, Map<Location, BlockData>> snapshots = new HashMap<>();

    public ArenaReset(SparkDuels plugin) { this.plugin = plugin; }

    public boolean enabled() { return plugin.getConfig().getBoolean("arena.reset", true); }

    /** Find the in-use arena containing this location, or null. */
    public Arena arenaAt(Location l) {
        if (!enabled() || l == null) return null;
        for (Arena a : plugin.arenas().all()) {
            if (a.inUse() && a.contains(l)) return a;
        }
        return null;
    }

    /** Record a block's CURRENT state before it changes (first change wins). */
    public void record(Block block, BlockData original) {
        Arena a = arenaAt(block.getLocation());
        if (a == null) return;
        snapshots.computeIfAbsent(a.name(), k -> new LinkedHashMap<>())
                .putIfAbsent(block.getLocation(), original);
    }

    public void record(Block block) {
        record(block, block.getBlockData());
    }

    /** Restore every recorded block for the arena, then clear the snapshot. */
    public void reset(Arena arena) {
        if (arena == null) return;
        Map<Location, BlockData> snap = snapshots.remove(arena.name());
        if (snap == null || snap.isEmpty()) return;
        World w = Bukkit.getWorld(arena.world());
        if (w == null) return;
        // restore in reverse insertion order so dependent blocks settle correctly
        var entries = new java.util.ArrayList<>(snap.entrySet());
        for (int i = entries.size() - 1; i >= 0; i--) {
            Location loc = entries.get(i).getKey();
            w.getBlockAt(loc).setBlockData(entries.get(i).getValue(), false);
        }
    }

    public void clearAll() { snapshots.clear(); }
}
