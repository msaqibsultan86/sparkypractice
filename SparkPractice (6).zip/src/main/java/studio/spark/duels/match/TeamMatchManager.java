package studio.spark.duels.match;

import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import studio.spark.duels.SparkDuels;
import studio.spark.duels.arena.Arena;
import studio.spark.duels.kit.Kit;
import studio.spark.duels.model.Mode;
import studio.spark.duels.util.Ctx;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Runs 2v2 / team matches alongside the 1v1 engine. */
public class TeamMatchManager {

    private final SparkDuels plugin;
    private final Map<UUID, TeamMatch> byPlayer = new HashMap<>();

    public TeamMatchManager(SparkDuels plugin) { this.plugin = plugin; }

    public boolean isInTeamMatch(Player p) { return byPlayer.containsKey(p.getUniqueId()); }
    public TeamMatch getMatch(Player p) { return byPlayer.get(p.getUniqueId()); }

    public void start(List<UUID> teamA, List<UUID> teamB, Mode mode, boolean ranked) {
        Kit kit = plugin.kits().get(mode.kit());
        if (kit == null) { broadcast(teamA, teamB, "kit.not-found", Ctx.of().put("kit", mode.kit())); return; }
        Arena arena = plugin.arenas().allocate();
        if (arena == null) { broadcast(teamA, teamB, "duel.no-arena", Ctx.of()); return; }

        TeamMatch match = new TeamMatch(teamA, teamB, mode, kit, arena, ranked);
        for (UUID id : match.members()) byPlayer.put(id, match);

        for (UUID id : teamA) prepare(plugin.getServer().getPlayer(id), arena.spawn1(), mode, kit);
        for (UUID id : teamB) prepare(plugin.getServer().getPlayer(id), arena.spawn2(), mode, kit);

        match.state(Match.State.PREPARING);
        countdown(match);
    }

    private void prepare(Player p, Location spawn, Mode mode, Kit kit) {
        if (p == null) return;
        if (spawn != null) p.teleport(spawn);
        p.setGameMode(GameMode.SURVIVAL);
        p.setHealth(p.getMaxHealth());
        p.setFoodLevel(20);
        p.setSaturation(20f);
        p.setFireTicks(0);
        p.setFallDistance(0f);
        p.getActivePotionEffects().forEach(e -> p.removePotionEffect(e.getType()));
        if (!plugin.playerKits().applyTo(p, mode.id())) kit.apply(p);
    }

    private void countdown(TeamMatch match) {
        int seconds = Math.max(1, plugin.getConfig().getInt("match.countdown-seconds", 5));
        new BukkitRunnable() {
            int left = seconds;
            @Override
            public void run() {
                if (match.state() == Match.State.ENDED || livingPlayers(match).isEmpty()) { cancel(); return; }
                if (left <= 0) {
                    match.state(Match.State.LIVE);
                    for (Player p : livingPlayers(match)) {
                        plugin.msg().title(p, "match.fight-title", "match.fight-subtitle", Ctx.of(), 0, 600, 200);
                        plugin.sounds().play(p, "fight");
                    }
                    cancel();
                    return;
                }
                Ctx ctx = Ctx.of().put("duel_countdown", String.valueOf(left));
                for (Player p : livingPlayers(match)) {
                    plugin.msg().title(p, "match.countdown-title", "match.countdown-subtitle", ctx, 0, 900, 100);
                    plugin.sounds().play(p, "countdown");
                }
                left--;
            }
        }.runTaskTimer(plugin, 0L, 20L);
    }

    /** Returns true if the victim was in a team match. */
    public boolean handleDeath(Player victim, Player killer) {
        TeamMatch match = getMatch(victim);
        if (match == null) return false;
        if (match.state() != Match.State.LIVE) return true;
        if (!match.isAlive(victim.getUniqueId())) return true;

        match.eliminate(victim.getUniqueId());
        victim.setGameMode(GameMode.SPECTATOR);
        if (plugin.getConfig().getBoolean("match.lightning-on-loss", true))
            victim.getWorld().strikeLightningEffect(victim.getLocation());

        Ctx ctx = Ctx.of().put("player", victim.getName()).put("target", killer != null ? killer.getName() : "?");
        for (Player p : livingPlayers(match)) plugin.msg().send(p, "team.eliminated", ctx);

        boolean aDead = match.aliveOnTeam(true) == 0;
        boolean bDead = match.aliveOnTeam(false) == 0;
        if (aDead || bDead) end(match, !aDead); // winner is team A if A still has players
        return true;
    }

    public void end(TeamMatch match, boolean teamAWins) {
        if (match.state() == Match.State.ENDED) return;
        match.state(Match.State.ENDED);
        for (UUID id : match.members()) byPlayer.remove(id);
        plugin.arenaReset().reset(match.arena());
        plugin.arenas().release(match.arena());

        List<UUID> winners = teamAWins ? match.teamA() : match.teamB();
        List<UUID> losers = teamAWins ? match.teamB() : match.teamA();
        reward(winners, losers, match.ranked());

        for (UUID id : winners) {
            Player w = plugin.getServer().getPlayer(id);
            if (w != null) {
                plugin.msg().title(w, "match.win-title", "match.win-subtitle", Ctx.of(), 200, 2000, 400);
                plugin.sounds().play(w, "win");
            }
        }
        for (UUID id : losers) {
            Player l = plugin.getServer().getPlayer(id);
            if (l != null) {
                plugin.msg().title(l, "match.loss-title", "match.loss-subtitle", Ctx.of(), 200, 2000, 400);
                plugin.sounds().play(l, "loss");
            }
        }
        String wNames = names(winners), lNames = names(losers);
        plugin.getServer().getOnlinePlayers().forEach(o ->
                plugin.msg().send(o, "team.win-broadcast", Ctx.of()
                        .put("duel_winner", wNames).put("duel_loser", lNames)
                        .put("duel_mode", match.mode().display())));

        long delay = Math.max(0, plugin.getConfig().getLong("match.end-delay-seconds", 3)) * 20L;
        for (UUID id : match.members()) {
            Player p = plugin.getServer().getPlayer(id);
            if (p != null) plugin.getServer().getScheduler().runTaskLater(plugin, () -> plugin.lobby().toLobby(p), delay);
        }
    }

    private void reward(List<UUID> winners, List<UUID> losers, boolean ranked) {
        int coins = plugin.getConfig().getInt("stats.coins-per-win", 10);
        int k = plugin.getConfig().getInt("stats.k-factor", 32);
        for (UUID id : winners) {
            var s = plugin.stats().get(id);
            s.wins++;
            s.streak++;
            if (s.streak > s.bestStreak) s.bestStreak = s.streak;
            s.coins += coins;
            if (ranked) s.elo += k / 2;
        }
        for (UUID id : losers) {
            var s = plugin.stats().get(id);
            s.losses++;
            s.streak = 0;
            if (ranked) s.elo = Math.max(0, s.elo - k / 2);
        }
        plugin.stats().save();
    }

    /** Quit during a team match = elimination (forfeit). */
    public void handleLeave(Player quitter) {
        TeamMatch match = getMatch(quitter);
        if (match == null) return;
        plugin.getServer().getOnlinePlayers().forEach(o ->
                plugin.msg().send(o, "match.combat-logged", Ctx.of().put("player", quitter.getName())));
        match.eliminate(quitter.getUniqueId());
        byPlayer.remove(quitter.getUniqueId());
        if (match.state() == Match.State.LIVE) {
            boolean aDead = match.aliveOnTeam(true) == 0;
            boolean bDead = match.aliveOnTeam(false) == 0;
            if (aDead || bDead) end(match, !aDead);
        }
    }

    public void tick() {
        for (TeamMatch m : new ArrayList<>(byPlayer.values())) {
            if (m.state() != Match.State.LIVE) continue;
            if (m.mode().type() == Mode.Type.NORMAL) continue;
            double floor = floorY(m.arena());
            for (UUID id : new ArrayList<>(m.members())) {
                if (!m.isAlive(id)) continue;
                Player p = plugin.getServer().getPlayer(id);
                if (p != null && p.getLocation().getY() < floor) handleDeath(p, null);
            }
        }
    }

    private double floorY(Arena a) {
        if (a.spawn1() == null) return -64;
        return Math.min(a.spawn1().getY(), a.spawn2() != null ? a.spawn2().getY() : a.spawn1().getY()) - 5;
    }

    private List<Player> livingPlayers(TeamMatch match) {
        List<Player> out = new ArrayList<>();
        for (UUID id : match.members()) {
            Player p = plugin.getServer().getPlayer(id);
            if (p != null) out.add(p);
        }
        return out;
    }

    private String names(List<UUID> team) {
        List<String> n = new ArrayList<>();
        for (UUID id : team) {
            Player p = plugin.getServer().getPlayer(id);
            n.add(p != null ? p.getName() : "?");
        }
        return String.join(" & ", n);
    }

    private void broadcast(List<UUID> a, List<UUID> b, String path, Ctx ctx) {
        List<UUID> all = new ArrayList<>(a); all.addAll(b);
        for (UUID id : all) {
            Player p = plugin.getServer().getPlayer(id);
            if (p != null) plugin.msg().send(p, path, ctx);
        }
    }

    private String circled(int n) {
        return switch (n) {
            case 1 -> "\u2460"; case 2 -> "\u2461"; case 3 -> "\u2462";
            case 4 -> "\u2463"; case 5 -> "\u2464"; case 6 -> "\u2465";
            case 7 -> "\u2466"; case 8 -> "\u2467"; case 9 -> "\u2468";
            default -> String.valueOf(n);
        };
    }
}
