package studio.spark.duels.match;

import studio.spark.duels.arena.Arena;
import studio.spark.duels.kit.Kit;
import studio.spark.duels.model.Mode;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/** A 2v2 (or NvN) team match. */
public class TeamMatch {

    private final List<UUID> teamA, teamB;
    private final Mode mode;
    private final Kit kit;
    private final Arena arena;
    private final boolean ranked;
    private final Set<UUID> alive = new HashSet<>();
    private Match.State state = Match.State.PREPARING;
    private final long startTime = System.currentTimeMillis();

    public TeamMatch(List<UUID> teamA, List<UUID> teamB, Mode mode, Kit kit, Arena arena, boolean ranked) {
        this.teamA = new ArrayList<>(teamA);
        this.teamB = new ArrayList<>(teamB);
        this.mode = mode;
        this.kit = kit;
        this.arena = arena;
        this.ranked = ranked;
        alive.addAll(this.teamA);
        alive.addAll(this.teamB);
    }

    public List<UUID> teamA() { return teamA; }
    public List<UUID> teamB() { return teamB; }
    public Mode mode() { return mode; }
    public Kit kit() { return kit; }
    public Arena arena() { return arena; }
    public boolean ranked() { return ranked; }
    public Match.State state() { return state; }
    public void state(Match.State s) { this.state = s; }
    public long elapsedSeconds() { return (System.currentTimeMillis() - startTime) / 1000L; }

    public List<UUID> members() {
        List<UUID> all = new ArrayList<>(teamA);
        all.addAll(teamB);
        return all;
    }

    public boolean onTeamA(UUID id) { return teamA.contains(id); }
    public boolean isAlive(UUID id) { return alive.contains(id); }
    public void eliminate(UUID id) { alive.remove(id); }

    public int aliveOnTeam(boolean teamAlpha) {
        int n = 0;
        for (UUID id : (teamAlpha ? teamA : teamB)) if (alive.contains(id)) n++;
        return n;
    }
}
