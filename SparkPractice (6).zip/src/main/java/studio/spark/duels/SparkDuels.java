package studio.spark.duels;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;
import studio.spark.duels.arena.ArenaManager;
import studio.spark.duels.commands.Commands;
import studio.spark.duels.duel.DuelManager;
import studio.spark.duels.kit.KitManager;
import studio.spark.duels.listeners.*;
import studio.spark.duels.lobby.LobbyManager;
import studio.spark.duels.match.MatchManager;
import studio.spark.duels.model.ModeManager;
import studio.spark.duels.party.PartyManager;
import studio.spark.duels.queue.QueueManager;
import studio.spark.duels.scoreboard.BoardManager;
import studio.spark.duels.stats.StatsManager;
import studio.spark.duels.util.ItemFactory;
import studio.spark.duels.util.Msg;
import studio.spark.duels.util.Placeholders;
import studio.spark.duels.util.Sounds;

import java.io.File;

/**
 * SparkDuels - premium duels/FFA/party/queue/kit/arena/scoreboard/stats plugin.
 * Made by Spark Studios. Theme: green gradient.
 */
public class SparkDuels extends JavaPlugin {

    private FileConfiguration messages, scoreboards, modesConfig, kitsConfig;

    private Msg msg;
    private Sounds sounds;
    private Placeholders placeholders;
    private ItemFactory items;

    private ModeManager modes;
    private KitManager kits;
    private ArenaManager arenas;
    private StatsManager stats;
    private MatchManager matches;
    private studio.spark.duels.match.TeamMatchManager teamMatches;
    private studio.spark.duels.arena.ArenaReset arenaReset;
    private QueueManager queue;
    private DuelManager duels;
    private PartyManager parties;
    private LobbyManager lobby;
    private BoardManager boards;
    private studio.spark.duels.ffa.FFAManager ffa;
    private studio.spark.duels.arena.Duplicator dup;
    private studio.spark.duels.kit.KitSerializer kitSerializer;
    private studio.spark.duels.kit.KitEditor kitEditor;
    private studio.spark.duels.lobby.LobbyItems lobbyItems;
    private studio.spark.duels.kit.PlayerKitManager playerKits;
    private studio.spark.duels.kit.PlayerKitEditor playerKitEditor;
    private studio.spark.duels.npc.LobbyNpcManager lobbyNpcs;
    private studio.spark.duels.world.BuildWorldManager buildWorld;
    private studio.spark.duels.schem.SchematicService schematics;
    private studio.spark.duels.tab.TabManager tab;
    private studio.spark.duels.anticheat.CheatWatch cheatWatch;
    private studio.spark.duels.leaderboard.LeaderboardHologram leaderboards;
    private studio.spark.duels.spectate.SpectatorManager spectators;
    private studio.spark.duels.duel.RematchManager rematches;
    private studio.spark.duels.shame.HallOfShame hallOfShame;
    private studio.spark.duels.util.SetupTools setupTools;

    private static final String[] COMMANDS = {
            "duel", "queue", "stats", "splaceholders", "ffa", "party", "kit", "modekit", "kiteditor", "kiteditorarea",
            "setlobby", "arena", "spos1", "spos2", "scorner1", "scorner2",
            "spduplicate", "sparena", "ffarena", "leaderboard",
            "togglescoreboard", "spectate", "rematch", "hallofshame", "sptools", "spnpc", "sparkpractice"
    };

    @Override
    public void onEnable() {
        saveDefaultConfig();
        for (String f : new String[]{"messages.yml", "scoreboards.yml", "modes.yml", "kits.yml",
                "party.yml", "ffa.yml", "arenas.yml", "stats.yml", "tab.yml"}) {
            saveResource(f, false);
        }
        loadConfigs();

        // utilities first (kit loading needs msg + items)
        msg = new Msg(this);
        sounds = new Sounds(this);
        placeholders = new Placeholders(this);
        items = new ItemFactory(this);

        // managers
        modes = new ModeManager(this);
        kits = new KitManager(this);
        arenas = new ArenaManager(this);
        stats = new StatsManager(this);
        matches = new MatchManager(this);
        teamMatches = new studio.spark.duels.match.TeamMatchManager(this);
        arenaReset = new studio.spark.duels.arena.ArenaReset(this);
        queue = new QueueManager(this);
        duels = new DuelManager(this);
        parties = new PartyManager(this);
        lobby = new LobbyManager(this);
        boards = new BoardManager(this);
        ffa = new studio.spark.duels.ffa.FFAManager(this);
        dup = new studio.spark.duels.arena.Duplicator(this);
        kitSerializer = new studio.spark.duels.kit.KitSerializer(this);
        kitEditor = new studio.spark.duels.kit.KitEditor(this);
        lobbyItems = new studio.spark.duels.lobby.LobbyItems(this);
        playerKits = new studio.spark.duels.kit.PlayerKitManager(this);
        playerKitEditor = new studio.spark.duels.kit.PlayerKitEditor(this);
        lobbyNpcs = new studio.spark.duels.npc.LobbyNpcManager(this);
        buildWorld = new studio.spark.duels.world.BuildWorldManager(this);
        schematics = new studio.spark.duels.schem.SchematicService(this);
        tab = new studio.spark.duels.tab.TabManager(this);
        cheatWatch = new studio.spark.duels.anticheat.CheatWatch(this);
        leaderboards = new studio.spark.duels.leaderboard.LeaderboardHologram(this);
        spectators = new studio.spark.duels.spectate.SpectatorManager(this);
        rematches = new studio.spark.duels.duel.RematchManager(this);
        hallOfShame = new studio.spark.duels.shame.HallOfShame(this);
        setupTools = new studio.spark.duels.util.SetupTools(this);

        Commands commands = new Commands(this);
        for (String c : COMMANDS) {
            if (getCommand(c) != null) {
                getCommand(c).setExecutor(commands);
                getCommand(c).setTabCompleter(commands);
            }
        }

        getServer().getPluginManager().registerEvents(new PlayerListener(this), this);
        getServer().getPluginManager().registerEvents(new ProtectionListener(this), this);
        getServer().getPluginManager().registerEvents(new CombatListener(this), this);
        getServer().getPluginManager().registerEvents(new MenuListener(this), this);
        getServer().getPluginManager().registerEvents(new studio.spark.duels.listeners.LobbyItemListener(this), this);
        getServer().getPluginManager().registerEvents(new studio.spark.duels.listeners.KitEditorListener(this), this);
        getServer().getPluginManager().registerEvents(new studio.spark.duels.listeners.CheatListener(this), this);
        getServer().getPluginManager().registerEvents(new studio.spark.duels.listeners.ArenaResetListener(this), this);
        getServer().getPluginManager().registerEvents(new studio.spark.duels.listeners.CombatExtrasListener(this), this);
        getServer().getPluginManager().registerEvents(new studio.spark.duels.listeners.SetupToolListener(this), this);
        getServer().getPluginManager().registerEvents(new studio.spark.duels.listeners.LobbyNpcListener(this), this);

        int sbTicks = Math.max(2, getConfig().getInt("settings.scoreboard-update-ticks", 10));
        getServer().getScheduler().runTaskTimer(this, () -> boards.tick(), 40L, sbTicks);
        getServer().getScheduler().runTaskTimer(this, () -> matches.tick(), 20L, 5L);
        getServer().getScheduler().runTaskTimer(this, () -> ffa.tick(), 20L, 5L);
        getServer().getScheduler().runTaskTimer(this, () -> teamMatches.tick(), 20L, 5L);
        getServer().getScheduler().runTaskTimer(this, () -> tab.tick(), 60L, tab.updateTicks());
        getServer().getScheduler().runTaskTimer(this, () -> stats.tickPlaytime(), 1200L, 1200L);   // +1 min every 60s
        getServer().getScheduler().runTaskTimer(this, () -> leaderboards.update(), 200L, 200L);      // refresh holos every 10s
        getServer().getScheduler().runTaskTimer(this, () -> spectators.tick(), 40L, 20L);            // return spectators when fight ends

        if (getServer().getPluginManager().isPluginEnabled("PlaceholderAPI")) {
            new studio.spark.duels.papi.SparkExpansion(this).register();
            getLogger().info("Hooked into PlaceholderAPI.");
        }


        getServer().getOnlinePlayers().forEach(p -> lobby.toLobby(p));
        leaderboards.load();
        hallOfShame.load();
        if (getConfig().contains("kit-editor.npc"))
            getServer().getScheduler().runTaskLater(this, () -> playerKitEditor.spawnNpc(), 40L);
        getServer().getScheduler().runTaskLater(this, () -> lobbyNpcs.load(), 40L);
        getServer().getScheduler().runTaskTimer(this, () -> lobbyNpcs.tickLook(), 60L, 5L);   // NPCs face nearby players
        studio.spark.duels.util.DownloadInfo.log(getLogger());
        getLogger().info("SparkPractice enabled - made by Spark Studios. Theme: green gradient.");
    }

    @Override
    public void onDisable() {
        if (matches != null) matches.endAll();
        if (stats != null) stats.save();
        if (leaderboards != null) leaderboards.saveAndDespawn();
        if (hallOfShame != null) hallOfShame.saveAndDespawn();
        if (arenas != null) arenas.save();
        if (ffa != null) ffa.save();
        if (playerKitEditor != null) playerKitEditor.removeNpcs();
        if (lobbyNpcs != null) lobbyNpcs.save();
        if (arenaReset != null) arenaReset.clearAll();
    }

    private void loadConfigs() {
        messages = load("messages.yml");
        scoreboards = load("scoreboards.yml");
        modesConfig = load("modes.yml");
        kitsConfig = load("kits.yml");
    }

    private FileConfiguration load(String name) {
        return YamlConfiguration.loadConfiguration(new File(getDataFolder(), name));
    }

    public void saveModesConfig() {
        try {
            ((YamlConfiguration) modesConfig).save(new File(getDataFolder(), "modes.yml"));
        } catch (Exception e) {
            getLogger().warning("Could not save modes.yml: " + e.getMessage());
        }
    }

    public void reloadAll() {
        reloadConfig();
        loadConfigs();
        modes.load();
        kits.load();
        arenas.load();
        stats.load();
        if (ffa != null) ffa.load();
        if (playerKits != null) playerKits.load();
        if (tab != null) tab.load();
    }

    // config accessors
    public FileConfiguration messages() { return messages; }
    public FileConfiguration scoreboards() { return scoreboards; }
    public FileConfiguration modesConfig() { return modesConfig; }
    public FileConfiguration kitsConfig() { return kitsConfig; }

    // util accessors
    public Msg msg() { return msg; }
    public Sounds sounds() { return sounds; }
    public Placeholders placeholders() { return placeholders; }
    public ItemFactory items() { return items; }

    // manager accessors
    public ModeManager modes() { return modes; }
    public KitManager kits() { return kits; }
    public ArenaManager arenas() { return arenas; }
    public StatsManager stats() { return stats; }
    public studio.spark.duels.leaderboard.LeaderboardHologram leaderboards() { return leaderboards; }
    public studio.spark.duels.spectate.SpectatorManager spectators() { return spectators; }
    public studio.spark.duels.duel.RematchManager rematches() { return rematches; }
    public studio.spark.duels.shame.HallOfShame hallOfShame() { return hallOfShame; }
    public studio.spark.duels.util.SetupTools setupTools() { return setupTools; }
    public MatchManager matches() { return matches; }
    public studio.spark.duels.match.TeamMatchManager teamMatches() { return teamMatches; }
    public studio.spark.duels.arena.ArenaReset arenaReset() { return arenaReset; }
    public QueueManager queue() { return queue; }
    public DuelManager duels() { return duels; }
    public PartyManager parties() { return parties; }
    public LobbyManager lobby() { return lobby; }
    public BoardManager boards() { return boards; }
    public studio.spark.duels.ffa.FFAManager ffa() { return ffa; }
    public studio.spark.duels.arena.Duplicator dup() { return dup; }
    public studio.spark.duels.kit.KitSerializer kitSerializer() { return kitSerializer; }
    public studio.spark.duels.kit.KitEditor kitEditor() { return kitEditor; }
    public studio.spark.duels.lobby.LobbyItems lobbyItems() { return lobbyItems; }
    public studio.spark.duels.kit.PlayerKitManager playerKits() { return playerKits; }
    public studio.spark.duels.kit.PlayerKitEditor playerKitEditor() { return playerKitEditor; }
    public studio.spark.duels.npc.LobbyNpcManager lobbyNpcs() { return lobbyNpcs; }
    public studio.spark.duels.world.BuildWorldManager buildWorld() { return buildWorld; }
    public studio.spark.duels.schem.SchematicService schematics() { return schematics; }
    public studio.spark.duels.tab.TabManager tab() { return tab; }
    public studio.spark.duels.anticheat.CheatWatch cheatWatch() { return cheatWatch; }
}
