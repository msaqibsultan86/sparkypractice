package studio.spark.duels.npc;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Villager;
import org.bukkit.persistence.PersistentDataType;
import studio.spark.duels.SparkDuels;
import studio.spark.duels.util.Ctx;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Built-in clickable lobby NPCs. Spawn with /spnpc spawn <type>.
 * Each NPC opens its matching menu/action when clicked. Unkillable + persistent via spnpcs.yml.
 */
public class LobbyNpcManager {

    private final SparkDuels plugin;
    private final NamespacedKey typeKey;
    private NpcBackend backend;   // set to CitizensHook when Citizens is installed

    /** Short, color-free names used for Citizens player NPCs (skins replace the look). */
    private static final Map<String, String> SHORT_NAMES = new LinkedHashMap<>();
    static {
        SHORT_NAMES.put("kiteditor",      "ᴋɪᴛ ᴇᴅɪᴛᴏʀ");
        SHORT_NAMES.put("ranked",         "ʀᴀɴᴋᴇᴅ");
        SHORT_NAMES.put("unranked",       "ᴜɴʀᴀɴᴋᴇᴅ");
        SHORT_NAMES.put("ffa",            "ꜰꜰᴀ");
        SHORT_NAMES.put("leaderboard",    "ʟᴇᴀᴅᴇʀʙᴏᴀʀᴅ");
        SHORT_NAMES.put("ffaleaderboard", "ꜰꜰᴀ ᴛᴏᴘ");
        SHORT_NAMES.put("party",          "ᴘᴀʀᴛʏ");
    }

    /** type id -> display label (MiniMessage). Order = what /spnpc types shows. */
    private static final Map<String, String> LABELS = new LinkedHashMap<>();
    static {
        LABELS.put("kiteditor",      "<gradient:#5DC8FF:#1F6FFF><bold>\u270E ᴋɪᴛ ᴇᴅɪᴛᴏʀ</bold></gradient>");
        LABELS.put("ranked",         "<gradient:#FFD23C:#FF7A00><bold>\u2694 ʀᴀɴᴋᴇᴅ ᴅᴜᴇʟ</bold></gradient>");
        LABELS.put("unranked",       "<gradient:#3CFF7E:#11A65B><bold>\u2694 ᴜɴʀᴀɴᴋᴇᴅ ᴅᴜᴇʟ</bold></gradient>");
        LABELS.put("ffa",            "<gradient:#FC5454:#A60000><bold>\u2620 ꜰꜰᴀ</bold></gradient>");
        LABELS.put("leaderboard",    "<gradient:#FFD23C:#FF7A00><bold>\uD83C\uDFC6 ʟᴇᴀᴅᴇʀʙᴏᴀʀᴅ</bold></gradient>");
        LABELS.put("ffaleaderboard", "<gradient:#FC5454:#A60000><bold>\uD83C\uDFC6 ꜰꜰᴀ ᴛᴏᴘ</bold></gradient>");
        LABELS.put("party",          "<gradient:#C77DFF:#7F4FD6><bold>\uD83D\uDC65 ᴘᴀʀᴛʏ</bold></gradient>");
    }

    public LobbyNpcManager(SparkDuels plugin) {
        this.plugin = plugin;
        this.typeKey = new NamespacedKey(plugin, "spnpc_type");
    }

    public static boolean isType(String t) { return t != null && LABELS.containsKey(t.toLowerCase(Locale.ROOT)); }
    public static java.util.Set<String> types() { return LABELS.keySet(); }

    public boolean isNpc(Entity e) {
        return e != null && e.getPersistentDataContainer().has(typeKey, PersistentDataType.STRING);
    }
    public String typeOf(Entity e) {
        return e == null ? null : e.getPersistentDataContainer().get(typeKey, PersistentDataType.STRING);
    }

    public void setBackend(NpcBackend b) { this.backend = b; }
    public boolean usingCitizens() { return backend != null; }

    /** Spawn an NPC of the given type at a location (optional skin for Citizens). Returns false if type unknown. */
    public boolean spawn(String type, Location loc, String skin) {
        if (loc == null || loc.getWorld() == null) return false;
        type = type.toLowerCase(Locale.ROOT);
        if (!LABELS.containsKey(type)) return false;
        if (backend != null) {                       // Citizens: player-skin NPC + look-close
            return backend.spawn(type, SHORT_NAMES.getOrDefault(type, type), skin, loc);
        }
        // native villager fallback
        loc.getChunk().load();
        Villager v = loc.getWorld().spawn(loc, Villager.class);
        v.setAI(false);
        v.setInvulnerable(true);
        v.setSilent(true);
        v.setGravity(false);
        v.setCollidable(false);
        v.setRemoveWhenFarAway(false);
        v.setPersistent(false);                 // we respawn from spnpcs.yml ourselves (no dupes)
        v.customName(plugin.msg().item(LABELS.get(type)));
        v.setCustomNameVisible(true);
        v.getPersistentDataContainer().set(typeKey, PersistentDataType.STRING, type);
        save();
        return true;
    }

    public boolean spawn(String type, Location loc) { return spawn(type, loc, null); }

    /** Remove the nearest NPC within 4 blocks of the player. Returns the removed type, or null. */
    public String removeNear(Player p) {
        if (backend != null) return backend.removeNear(p);
        Entity best = null;
        double bestD = 16.0;   // 4 blocks squared
        for (Entity e : p.getWorld().getNearbyEntities(p.getLocation(), 4, 4, 4)) {
            if (isNpc(e)) {
                double d = e.getLocation().distanceSquared(p.getLocation());
                if (d < bestD) { bestD = d; best = e; }
            }
        }
        if (best == null) return null;
        String t = typeOf(best);
        best.remove();
        save();
        return t;
    }

    public int removeAll() {
        if (backend != null) return backend.removeAll();
        int n = 0;
        for (World w : Bukkit.getWorlds())
            for (Entity e : w.getEntities())
                if (isNpc(e)) { e.remove(); n++; }
        save();
        return n;
    }

    /** Live list of spawned NPCs as "type @ world x,y,z". */
    public List<String> list() {
        if (backend != null) return backend.list();
        List<String> out = new ArrayList<>();
        for (World w : Bukkit.getWorlds())
            for (Entity e : w.getEntities())
                if (isNpc(e)) {
                    Location l = e.getLocation();
                    out.add(typeOf(e) + " @ " + w.getName() + " "
                            + l.getBlockX() + "," + l.getBlockY() + "," + l.getBlockZ());
                }
        return out;
    }

    /** Run the NPC's action for a player. */
    public void run(String type, Player p) {
        if (type == null) return;
        if (plugin.matches().isInMatch(p) || plugin.ffa().isInFfa(p)) {
            plugin.msg().send(p, "duel.already-in-match");
            return;
        }
        switch (type) {
            case "kiteditor"      -> plugin.playerKitEditor().openKitMenu(p);
            case "ranked"         -> studio.spark.duels.gui.QueueMenu.open(plugin, p, true);
            case "unranked"       -> studio.spark.duels.gui.QueueMenu.open(plugin, p, false);
            case "ffa"            -> studio.spark.duels.gui.FFAMenu.open(plugin, p);
            case "leaderboard"    -> studio.spark.duels.gui.LeaderboardMenu.open(plugin, p, false);
            case "ffaleaderboard" -> studio.spark.duels.gui.LeaderboardMenu.open(plugin, p, true);
            case "party"          -> studio.spark.duels.gui.PartyMenu.open(plugin, p);
            default -> {}
        }
        plugin.sounds().play(p, "click");
    }

    // ---- persistence (spnpcs.yml) ----
    private File file() { return new File(plugin.getDataFolder(), "spnpcs.yml"); }

    public void save() {
        YamlConfiguration cfg = new YamlConfiguration();
        List<Map<String, Object>> npcs = new ArrayList<>();
        for (World w : Bukkit.getWorlds())
            for (Entity e : w.getEntities())
                if (isNpc(e)) {
                    Location l = e.getLocation();
                    Map<String, Object> m = new LinkedHashMap<>();
                    m.put("type", typeOf(e));
                    m.put("world", w.getName());
                    m.put("x", l.getX()); m.put("y", l.getY()); m.put("z", l.getZ());
                    m.put("yaw", l.getYaw()); m.put("pitch", l.getPitch());
                    npcs.add(m);
                }
        cfg.set("npcs", npcs);
        try { cfg.save(file()); } catch (Exception ex) { plugin.getLogger().warning("Could not save spnpcs.yml: " + ex.getMessage()); }
    }

    /** Clear any stray tagged NPCs, then respawn all from spnpcs.yml. */
    @SuppressWarnings("unchecked")
    public void load() {
        if (backend != null) return;   // Citizens persists its own NPCs
        for (World w : Bukkit.getWorlds())
            for (Entity e : w.getEntities())
                if (isNpc(e)) e.remove();
        File f = file();
        if (!f.exists()) return;
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(f);
        List<Map<?, ?>> npcs = cfg.getMapList("npcs");
        for (Map<?, ?> m : npcs) {
            String type = String.valueOf(m.get("type"));
            World w = Bukkit.getWorld(String.valueOf(m.get("world")));
            if (w == null || !LABELS.containsKey(type)) continue;
            Location loc = new Location(w,
                    num(m.get("x")), num(m.get("y")), num(m.get("z")),
                    (float) num(m.get("yaw")), (float) num(m.get("pitch")));
            spawnNoSave(type, loc);
        }
    }

    private void spawnNoSave(String type, Location loc) {
        loc.getChunk().load();
        Villager v = loc.getWorld().spawn(loc, Villager.class);
        v.setAI(false); v.setInvulnerable(true); v.setSilent(true);
        v.setGravity(false); v.setCollidable(false); v.setRemoveWhenFarAway(false); v.setPersistent(false);
        v.customName(plugin.msg().item(LABELS.get(type)));
        v.setCustomNameVisible(true);
        v.getPersistentDataContainer().set(typeKey, PersistentDataType.STRING, type);
    }

    private static double num(Object o) { return o instanceof Number n ? n.doubleValue() : 0.0; }

    /** Rotate every NPC to face the nearest player within range (called on a timer). */
    public void tickLook() {
        if (backend != null) return;   // Citizens LookClose handles facing
        double range = plugin.getConfig().getDouble("npc.look-range", 10.0);
        double range2 = range * range;
        for (World w : Bukkit.getWorlds()) {
            List<Player> players = w.getPlayers();
            if (players.isEmpty()) continue;
            for (Entity e : w.getEntities()) {
                if (!isNpc(e)) continue;
                Player nearest = null;
                double best = range2;
                for (Player pl : players) {
                    double d = pl.getLocation().distanceSquared(e.getLocation());
                    if (d < best) { best = d; nearest = pl; }
                }
                if (nearest == null) continue;
                Location look = e.getLocation().clone();
                org.bukkit.util.Vector dir = nearest.getEyeLocation().toVector().subtract(look.toVector());
                if (dir.lengthSquared() < 1.0e-4) continue;
                look.setDirection(dir);
                look.setPitch(0f);                 // stay upright, turn horizontally only
                e.teleport(look);
            }
        }
    }
}
