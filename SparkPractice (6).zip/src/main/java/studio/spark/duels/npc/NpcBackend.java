package studio.spark.duels.npc;

import org.bukkit.Location;
import org.bukkit.entity.Player;

import java.util.List;

/**
 * Pluggable NPC backend. Implemented by CitizensHook when Citizens is present.
 * Uses only Bukkit/JDK types so the rest of the plugin never loads Citizens classes
 * unless Citizens is actually installed.
 */
public interface NpcBackend {
    boolean spawn(String type, String name, String skin, Location loc);
    String removeNear(Player p);
    int removeAll();
    List<String> list();
}
