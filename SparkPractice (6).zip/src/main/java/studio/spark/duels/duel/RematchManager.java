package studio.spark.duels.duel;

import org.bukkit.entity.Player;
import studio.spark.duels.SparkDuels;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Remembers each player's last opponent + mode so they can /rematch. */
public class RematchManager {

    private final SparkDuels plugin;
    private final Map<UUID, UUID> lastOpponent = new HashMap<>();
    private final Map<UUID, String> lastMode = new HashMap<>();

    public RematchManager(SparkDuels plugin) { this.plugin = plugin; }

    /** Record a finished duel for both players. */
    public void record(UUID a, UUID b, String modeId) {
        if (a == null || b == null || modeId == null) return;
        lastOpponent.put(a, b); lastMode.put(a, modeId);
        lastOpponent.put(b, a); lastMode.put(b, modeId);
    }

    public void rematch(Player p) {
        UUID oppId = lastOpponent.get(p.getUniqueId());
        String modeId = lastMode.get(p.getUniqueId());
        if (oppId == null || modeId == null) { plugin.msg().send(p, "rematch.none"); return; }
        Player opp = plugin.getServer().getPlayer(oppId);
        if (opp == null || !opp.isOnline()) { plugin.msg().send(p, "rematch.offline"); return; }
        if (plugin.matches().isInMatch(p) || plugin.matches().isInMatch(opp)) {
            plugin.msg().send(p, "rematch.busy"); return;
        }
        plugin.duels().send(p, opp, modeId);
    }
}
