package studio.spark.duels.world;

import org.bukkit.GameRule;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.entity.Player;
import studio.spark.duels.SparkDuels;

import java.util.concurrent.ThreadLocalRandom;

/** Manages the void "build world" used for pasting arena schematics, plus the schematics folder. */
public class BuildWorldManager {

    private final SparkDuels plugin;
    private final String worldName;

    public BuildWorldManager(SparkDuels plugin) {
        this.plugin = plugin;
        this.worldName = plugin.getConfig().getString("build-world.name", "sparkpractice_build");
    }


    /** Get (creating/loading if needed) the void build world. Returns null on failure. */
    public World voidWorld() {
        World w = plugin.getServer().getWorld(worldName);
        if (w != null) return w;
        try {
            w = new WorldCreator(worldName)
                    .generator(new VoidGenerator())
                    .environment(World.Environment.NORMAL)
                    .createWorld();
            if (w != null) {
                w.setGameRule(GameRule.DO_MOB_SPAWNING, false);
                w.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, false);
                w.setGameRule(GameRule.DO_WEATHER_CYCLE, false);
                w.setGameRule(GameRule.KEEP_INVENTORY, true);
                w.setGameRule(GameRule.FALL_DAMAGE, false);
                w.setGameRule(GameRule.DO_FIRE_TICK, false);
                w.setTime(6000);
                w.setStorm(false);
                w.setDifficulty(org.bukkit.Difficulty.PEACEFUL);
            }
            return w;
        } catch (Throwable t) {
            plugin.getLogger().warning("Could not create build world: " + t.getMessage());
            return null;
        }
    }

    /** Teleport the player to a random open spot in the void world (flight on, won't fall). */
    public void sendToRandomArea(Player p) {
        World w = voidWorld();
        if (w == null) {
            plugin.msg().sendRaw(p, plugin.msg().prefix()
                    + "<#FC5454>ᴄᴏᴜʟᴅɴ'ᴛ ᴏᴘᴇɴ ᴛʜᴇ ʙᴜɪʟᴅ ᴡᴏʀʟᴅ. <gray>ᴄʜᴇᴄᴋ ᴄᴏɴsᴏʟᴇ.",
                    studio.spark.duels.util.Ctx.of());
            return;
        }
        // random, widely-spaced spot so arenas never overlap
        int x = ThreadLocalRandom.current().nextInt(-100000, 100000);
        int z = ThreadLocalRandom.current().nextInt(-100000, 100000);
        Location loc = new Location(w, x + 0.5, 120, z + 0.5);
        w.getChunkAt(loc).load();
        p.teleport(loc);
        p.setAllowFlight(true);
        p.setFlying(true);
        plugin.msg().sendRaw(p, plugin.msg().prefix()
                + "<#3CFF7E>ᴛᴇʟᴇᴘᴏʀᴛᴇᴅ ᴛᴏ ᴀ ꜰʀᴇsʜ ᴠᴏɪᴅ ᴀʀᴇᴀ <gray>(" + x + ", " + z + ").",
                studio.spark.duels.util.Ctx.of());
        plugin.msg().sendRaw(p, "<gray>ʙᴜɪʟᴅ ᴏʀ <white>/arena schem load <name> <gray>ᴛʜᴇɴ <white>/arena schem paste<gray>.",
                studio.spark.duels.util.Ctx.of());
        plugin.sounds().play(p, "gui-open");
    }


}
