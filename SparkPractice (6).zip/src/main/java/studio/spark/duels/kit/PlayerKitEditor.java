package studio.spark.duels.kit;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.MagmaCube;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Slime;
import org.bukkit.entity.Villager;
import org.bukkit.persistence.PersistentDataType;
import studio.spark.duels.SparkDuels;
import studio.spark.duels.gui.KitEditorMenu;
import studio.spark.duels.model.Mode;
import studio.spark.duels.util.Ctx;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/** Per-player kit editor: TP to area, pick a mode, edit, click the green NPC to save. */
public class PlayerKitEditor {

    private final SparkDuels plugin;
    private final NamespacedKey npcKey;
    private final NamespacedKey leaveKey;
    private final NamespacedKey menuKey;
    private final Map<UUID, String> editing = new HashMap<>();

    public PlayerKitEditor(SparkDuels plugin) {
        this.plugin = plugin;
        this.npcKey = new NamespacedKey(plugin, "kiteditor_npc");
        this.leaveKey = new NamespacedKey(plugin, "kiteditor_leave_npc");
        this.menuKey = new NamespacedKey(plugin, "kiteditor_menu_npc");
    }

    public boolean isEditing(Player p) { return editing.containsKey(p.getUniqueId()); }
    public boolean areaConfigured() { return spawn() != null; }

    public Location spawn() { return readLoc("kit-editor.spawn"); }
    public Location npc() { Location n = readLoc("kit-editor.npc"); return n != null ? n : spawn(); }
    public Location corner1() { return readLoc("kit-editor.corner1"); }
    public Location corner2() { return readLoc("kit-editor.corner2"); }

    public void openMenu(Player p) {
        if (plugin.matches().isInMatch(p) || plugin.ffa().isInFfa(p) || plugin.queue().isQueued(p)) {
            plugin.msg().send(p, "duel.already-in-match");
            return;
        }
        if (!areaConfigured()) { plugin.msg().send(p, "kiteditor.not-setup"); return; }
        p.teleport(spawn());
        KitEditorMenu.open(plugin, p);
    }

    public void selectMode(Player p, String modeId) {
        Mode mode = plugin.modes().get(modeId);
        if (mode == null) { plugin.msg().send(p, "kit.not-found", Ctx.of().put("kit", modeId)); return; }
        editing.put(p.getUniqueId(), mode.id().toLowerCase(Locale.ROOT));
        p.getInventory().clear();
        if (!plugin.playerKits().applyTo(p, mode.id())) {
            Kit def = plugin.kits().get(mode.kit());
            if (def != null) def.apply(p);
        }
        p.setGameMode(GameMode.CREATIVE);
        plugin.msg().send(p, "kiteditor.editing", Ctx.of().put("mode", mode.display()));
        plugin.sounds().play(p, "gui-open");
    }

    public void save(Player p) {
        String modeId = editing.remove(p.getUniqueId());
        if (modeId == null) return;
        plugin.playerKits().store(p, modeId);
        plugin.msg().send(p, "kiteditor.saved");
        plugin.sounds().play(p, "success");
        plugin.lobby().toLobby(p);
    }

    public void cancel(Player p) {
        if (editing.remove(p.getUniqueId()) != null) p.getInventory().clear();
    }

    /** Leave the editor without saving. */
    public void leave(Player p) {
        cancel(p);
        plugin.lobby().toLobby(p);
        plugin.sounds().play(p, "click");
    }

    // ---- NPCs: green slime = save, red magma = leave, villager = kit menu. All unkillable. ----
    public boolean isNpc(Entity e) {
        return e != null && e.getPersistentDataContainer().has(npcKey, PersistentDataType.BYTE);
    }
    public boolean isLeaveNpc(Entity e) {
        return e != null && e.getPersistentDataContainer().has(leaveKey, PersistentDataType.BYTE);
    }
    public boolean isMenuNpc(Entity e) {
        return e != null && e.getPersistentDataContainer().has(menuKey, PersistentDataType.BYTE);
    }

    public Location leaveNpc() { return readLoc("kit-editor.leave-npc"); }
    public Location menuNpc()  { return readLoc("kit-editor.menu-npc"); }

    /** Opens the kit-select menu (used by the center NPC). */
    public void openKitMenu(Player p) {
        if (plugin.matches().isInMatch(p) || plugin.ffa().isInFfa(p) || plugin.queue().isQueued(p)) {
            plugin.msg().send(p, "duel.already-in-match");
            return;
        }
        KitEditorMenu.open(plugin, p);
    }

    public void spawnNpc() {
        removeNpcs();
        spawnNpcEntity(npc(), Slime.class, npcKey,
                "<gradient:#3CFF7E:#11A65B><bold>\u2714 ᴄʟɪᴄᴋ ᴛᴏ sᴀᴠᴇ ᴋɪᴛ</bold></gradient>");
        Location leave = leaveNpc();
        if (leave != null) spawnNpcEntity(leave, MagmaCube.class, leaveKey,
                "<gradient:#FC5454:#A60000><bold>\u2716 ʟᴇᴀᴠᴇ ᴛᴏ ʟᴏʙʙʏ</bold></gradient>");
        Location menu = menuNpc();
        if (menu != null) spawnNpcEntity(menu, Villager.class, menuKey,
                "<gradient:#5DC8FF:#1F6FFF><bold>\u270E ᴄʟɪᴄᴋ ᴛᴏ ᴘɪᴄᴋ ᴀ ᴋɪᴛ</bold></gradient>");
    }

    private <T extends Mob> void spawnNpcEntity(Location loc, Class<T> type, NamespacedKey key, String name) {
        if (loc == null || loc.getWorld() == null) return;
        loc.getChunk().load();
        T e = loc.getWorld().spawn(loc, type);
        if (e instanceof Slime sl) sl.setSize(2);
        e.setAI(false);
        e.setInvulnerable(true);   // immune to damage
        e.setSilent(true);
        e.setGravity(false);
        e.setCollidable(false);
        e.setRemoveWhenFarAway(false);
        e.setPersistent(true);
        e.customName(plugin.msg().item(name));
        e.setCustomNameVisible(true);
        e.getPersistentDataContainer().set(key, PersistentDataType.BYTE, (byte) 1);
    }

    public void removeNpcs() {
        for (World w : Bukkit.getWorlds())
            for (Entity e : w.getEntities()) {
                var pdc = e.getPersistentDataContainer();
                if (pdc.has(npcKey, PersistentDataType.BYTE)
                        || pdc.has(leaveKey, PersistentDataType.BYTE)
                        || pdc.has(menuKey, PersistentDataType.BYTE))
                    e.remove();
            }
    }

    /** Auto-builds a sealed black-concrete editor room with both NPCs + lighting. */
    public void buildRoom(Player p) {
        Location base = p.getLocation();
        World w = base.getWorld();
        int cx = base.getBlockX(), cy = base.getBlockY(), cz = base.getBlockZ();
        int half = 5, height = 5;
        int minX = cx - half, maxX = cx + half, minZ = cz - half, maxZ = cz + half;
        int floorY = cy - 1, ceilY = cy + height;

        for (int x = minX; x <= maxX; x++)
            for (int z = minZ; z <= maxZ; z++)
                for (int y = floorY; y <= ceilY; y++) {
                    boolean shell = x == minX || x == maxX || z == minZ || z == maxZ || y == floorY || y == ceilY;
                    w.getBlockAt(x, y, z).setType(shell ? Material.BLACK_CONCRETE : Material.AIR, false);
                }
        // invisible light sources so the black room is fully lit
        int ly = ceilY - 1;
        int[][] lights = {{0, 0}, {-3, -3}, {3, 3}, {-3, 3}, {3, -3}};
        for (int[] o : lights) w.getBlockAt(cx + o[0], ly, cz + o[1]).setType(Material.LIGHT, false);

        Location spawn = new Location(w, cx + 0.5, floorY + 1, cz - 3.5, 0f, 0f);          // back, faces +Z
        Location menuNpc = new Location(w, cx + 0.5, floorY + 1, cz + 0.5, 180f, 0f);      // CENTER kit menu
        Location saveNpc = new Location(w, cx + 3.5, floorY + 1, cz + 3.5, 200f, 0f);      // green, right corner
        Location leaveNpc = new Location(w, cx - 3.5, floorY + 1, cz + 3.5, 160f, 0f);     // red, left corner
        Location c1 = new Location(w, minX + 1, floorY + 1, minZ + 1);
        Location c2 = new Location(w, maxX - 1, ceilY - 1, maxZ - 1);

        writeLoc("kit-editor.spawn", spawn);
        writeLoc("kit-editor.menu-npc", menuNpc);
        writeLoc("kit-editor.npc", saveNpc);
        writeLoc("kit-editor.leave-npc", leaveNpc);
        writeLoc("kit-editor.corner1", c1);
        writeLoc("kit-editor.corner2", c2);

        spawnNpc();
        p.teleport(spawn);
        plugin.msg().sendRaw(p, plugin.msg().prefix()
                + "<#3CFF7E>ʙᴜɪʟᴛ ᴀ sᴇᴀʟᴇᴅ ᴋɪᴛ-ᴇᴅɪᴛᴏʀ ʀᴏᴏᴍ <gray>(ᴋɪᴛ ᴍᴇɴᴜ ᴄᴇɴᴛᴇʀ, sᴀᴠᴇ + ʟᴇᴀᴠᴇ ɪɴ ᴄᴏʀɴᴇʀs).", studio.spark.duels.util.Ctx.of());
    }

    // ---- config location helpers ----
    private Location readLoc(String path) {
        var sec = plugin.getConfig().getConfigurationSection(path);
        if (sec == null) return null;
        World w = Bukkit.getWorld(sec.getString("world", ""));
        if (w == null) return null;
        return new Location(w, sec.getDouble("x"), sec.getDouble("y"), sec.getDouble("z"),
                (float) sec.getDouble("yaw"), (float) sec.getDouble("pitch"));
    }

    public void writeLoc(String path, Location l) {
        plugin.getConfig().set(path + ".world", l.getWorld().getName());
        plugin.getConfig().set(path + ".x", l.getX());
        plugin.getConfig().set(path + ".y", l.getY());
        plugin.getConfig().set(path + ".z", l.getZ());
        plugin.getConfig().set(path + ".yaw", (double) l.getYaw());
        plugin.getConfig().set(path + ".pitch", (double) l.getPitch());
        plugin.saveConfig();
    }
}
