package studio.spark.duels.schem;

import studio.spark.duels.nbt.Nbt;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * A parsed Sponge .schem (v2 or v3). Stores dimensions, a palette of block-state strings,
 * and one palette index per block (y,z,x order). Block-only (no block entities/entities) —
 * which is all an arena needs.
 */
public class Schematic {

    public final int width, height, length;
    public final String[] palette;   // id -> blockdata string e.g. "minecraft:oak_stairs[facing=east]"
    public final int[] blocks;       // length width*height*length, values index into palette

    private Schematic(int w, int h, int l, String[] palette, int[] blocks) {
        this.width = w; this.height = h; this.length = l;
        this.palette = palette; this.blocks = blocks;
    }

    public String stateAt(int index) {
        int id = blocks[index];
        return id >= 0 && id < palette.length ? palette[id] : "minecraft:air";
    }

    /** Load a Sponge schematic (.schem). Supports v2 (Palette/BlockData at root) and v3 (Blocks compound). */
    public static Schematic load(File file) throws IOException {
        Map<String, Object> root = Nbt.read(file);

        // v3 nests everything under "Schematic"
        Map<String, Object> s = Nbt.getMap(root, "Schematic");
        if (s == null) s = root;

        int width  = Nbt.getInt(s, "Width", 0);
        int height = Nbt.getInt(s, "Height", 0);
        int length = Nbt.getInt(s, "Length", 0);
        if (width <= 0 || height <= 0 || length <= 0)
            throw new IOException("Bad schematic dimensions " + width + "x" + height + "x" + length);

        // v3: palette + data live in a "Blocks" compound; v2: at this level
        Map<String, Object> paletteMap;
        byte[] data;
        Map<String, Object> blocksC = Nbt.getMap(s, "Blocks");
        if (blocksC != null) {
            paletteMap = Nbt.getMap(blocksC, "Palette");
            data = Nbt.getBytes(blocksC, "Data");
        } else {
            paletteMap = Nbt.getMap(s, "Palette");
            data = Nbt.getBytes(s, "BlockData");
        }
        if (paletteMap == null || data == null)
            throw new IOException("Schematic missing Palette or BlockData");

        // build id -> state string
        int max = 0;
        for (Object v : paletteMap.values()) if (v instanceof Number n) max = Math.max(max, n.intValue());
        String[] palette = new String[max + 1];
        for (Map.Entry<String, Object> e : paletteMap.entrySet())
            if (e.getValue() instanceof Number n) palette[n.intValue()] = e.getKey();
        for (int i = 0; i < palette.length; i++) if (palette[i] == null) palette[i] = "minecraft:air";

        // decode varint block indices
        int total = width * height * length;
        int[] blocks = new int[total];
        int pos = 0, i = 0;
        while (pos < data.length && i < total) {
            int value = 0, shift = 0, read;
            do {
                read = data[pos++] & 0xFF;
                value |= (read & 0x7F) << shift;
                shift += 7;
            } while ((read & 0x80) != 0 && pos < data.length);
            blocks[i++] = value;
        }

        return new Schematic(width, height, length, palette, blocks);
    }
}
