package studio.spark.duels.schem;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import studio.spark.duels.SparkDuels;
import studio.spark.duels.util.Ctx;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Loads, holds (per-player clipboard), and pastes schematics natively — no WorldEdit. */
public class SchematicService {

    private final SparkDuels plugin;
    private final Map<UUID, Schematic> clipboard = new HashMap<>();
    private final Map<String, BlockData> dataCache = new HashMap<>();

    public SchematicService(SparkDuels plugin) {
        this.plugin = plugin;
        File dir = folder();
        if (!dir.exists()) dir.mkdirs();
    }

    public File folder() { return new File(plugin.getDataFolder(), "schematics"); }

    public List<String> list() {
        List<String> out = new ArrayList<>();
        File[] files = folder().listFiles();
        if (files != null)
            for (File f : files) {
                String n = f.getName().toLowerCase();
                if (n.endsWith(".schem") || n.endsWith(".schematic")) out.add(f.getName());
            }
        return out;
    }

    /** Load a schematic file into the player's clipboard. Returns an error string, or null on success. */
    public String load(Player p, String name) {
        File f = resolve(name);
        if (f == null) return "ɴᴏ sᴄʜᴇᴍᴀᴛɪᴄ ɴᴀᴍᴇᴅ '" + name + "'";
        try {
            Schematic s = Schematic.load(f);
            clipboard.put(p.getUniqueId(), s);
            return null;
        } catch (Throwable t) {
            plugin.getLogger().warning("Schematic load failed (" + f.getName() + "): " + t);
            return "ꜰᴀɪʟᴇᴅ ᴛᴏ ʀᴇᴀᴅ ᴛʜᴀᴛ ꜰɪʟᴇ (" + t.getClass().getSimpleName() + ")";
        }
    }

    public boolean hasClipboard(Player p) { return clipboard.containsKey(p.getUniqueId()); }

    /** Paste the player's clipboard at their location, batched over ticks so the server never freezes. */
    public void paste(Player p) {
        Schematic s = clipboard.get(p.getUniqueId());
        if (s == null) {
            plugin.msg().sendRaw(p, plugin.msg().prefix() + "<#FC5454>ɴᴏᴛʜɪɴɢ ʟᴏᴀᴅᴇᴅ. ᴜsᴇ <white>/arena schem load <name>", Ctx.of());
            return;
        }
        World w = p.getWorld();
        Location base = p.getLocation().getBlock().getLocation();
        int bx = base.getBlockX(), by = base.getBlockY(), bz = base.getBlockZ();

        plugin.msg().sendRaw(p, plugin.msg().prefix() + "<#3CFF7E>ᴘᴀsᴛɪɴɢ <white>"
                + (s.width * s.height * s.length) + " <#3CFF7E>ʙʟᴏᴄᴋs...", Ctx.of());

        final int perTick = 20000;
        new BukkitRunnable() {
            int i = 0;
            @Override public void run() {
                int done = 0;
                while (i < s.blocks.length && done < perTick) {
                    int y = i / (s.width * s.length);
                    int rem = i % (s.width * s.length);
                    int z = rem / s.width;
                    int x = rem % s.width;
                    String state = s.stateAt(i);
                    i++; done++;
                    if (state.equals("minecraft:air")) continue;   // skip air (don't carve holes)
                    BlockData data = data(state);
                    if (data == null) continue;
                    w.getBlockAt(bx + x, by + y, bz + z).setBlockData(data, false);
                }
                if (i >= s.blocks.length) {
                    cancel();
                    plugin.msg().sendRaw(p, plugin.msg().prefix()
                            + "<#3CFF7E>\u2714 ᴘᴀsᴛᴇᴅ! ɴᴏᴡ sᴇᴛ ɪᴛ ᴜᴘ ᴡɪᴛʜ <white>/sptools<#3CFF7E>.", Ctx.of());
                    plugin.sounds().play(p, "gui-open");
                }
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    private BlockData data(String state) {
        BlockData cached = dataCache.get(state);
        if (cached != null) return cached;
        try {
            BlockData d = Bukkit.createBlockData(state);
            dataCache.put(state, d);
            return d;
        } catch (Throwable t) {
            // unknown block on this version -> try the bare material, else skip
            try {
                String id = state.contains("[") ? state.substring(0, state.indexOf('[')) : state;
                Material m = Material.matchMaterial(id);
                BlockData d = m != null ? m.createBlockData() : null;
                dataCache.put(state, d);
                return d;
            } catch (Throwable t2) {
                dataCache.put(state, null);
                return null;
            }
        }
    }

    private File resolve(String name) {
        File dir = folder();
        for (String ext : new String[]{"", ".schem", ".schematic"}) {
            File f = new File(dir, name + ext);
            if (f.isFile()) return f;
        }
        return null;
    }
}
