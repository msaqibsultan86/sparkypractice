package studio.spark.duels.model;

import org.bukkit.Material;

public class Mode {

    public enum Type { NORMAL, SUMO, SPLEEF }

    private final String id;
    private final String display;
    private final Material icon;
    private final String kit;
    private final Type type;
    private final int slot;
    private final boolean duel;
    private final boolean ffa;

    public Mode(String id, String display, Material icon, String kit, Type type, int slot, boolean duel, boolean ffa) {
        this.id = id;
        this.display = display;
        this.icon = icon;
        this.kit = kit;
        this.type = type;
        this.slot = slot;
        this.duel = duel;
        this.ffa = ffa;
    }

    public String id() { return id; }
    public String display() { return display; }
    public Material icon() { return icon; }
    public String kit() { return kit; }
    public Type type() { return type; }
    public int slot() { return slot; }
    public boolean duel() { return duel; }
    public boolean ffa() { return ffa; }

    /** Pretty, small-caps kit name for menus: "SpearMaceKit" -> "sᴘᴇᴀʀ ᴍᴀᴄᴇ". */
    public String kitPretty() {
        String s = kit == null ? "" : kit;
        if (s.endsWith("Kit")) s = s.substring(0, s.length() - 3);
        s = s.replaceAll("(?<=[a-z0-9])(?=[A-Z])", " ").trim();   // camelCase -> spaced
        return smallCaps(s);
    }

    private static final String SMALL = "ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘǫʀsᴛᴜᴠᴡxʏᴢ";
    private static String smallCaps(String in) {
        StringBuilder b = new StringBuilder();
        for (char c : in.toLowerCase(java.util.Locale.ROOT).toCharArray()) {
            int i = c - 'a';
            b.append(i >= 0 && i < 26 ? SMALL.charAt(i) : c);
        }
        return b.toString();
    }
}
