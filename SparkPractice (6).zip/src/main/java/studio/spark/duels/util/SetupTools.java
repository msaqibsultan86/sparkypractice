package studio.spark.duels.util;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import studio.spark.duels.SparkDuels;

import java.util.List;

/** Builds + identifies the /sptools arena-setup wand items. */
public class SetupTools {

    private final SparkDuels plugin;
    private final NamespacedKey key;

    public SetupTools(SparkDuels plugin) {
        this.plugin = plugin;
        this.key = new NamespacedKey(plugin, "sptool");
    }

    /** Returns the tool action of an item ("pos1"/"pos2"/"corner1"/"corner2"/"lobby") or null. */
    public String actionOf(ItemStack it) {
        if (it == null || !it.hasItemMeta()) return null;
        return it.getItemMeta().getPersistentDataContainer().get(key, PersistentDataType.STRING);
    }

    public void give(Player p) {
        p.getInventory().addItem(
                tool(Material.LIME_DYE,   "pos1",    "<#3CFF7E><bold>\u2691 ᴘᴏs 1</bold> <gray>(sᴘᴀᴡɴ ᴀ)", "ʀɪɢʜᴛ-ᴄʟɪᴄᴋ ᴛᴏ sᴇᴛ sᴘᴀᴡɴ ᴀ"),
                tool(Material.PINK_DYE,   "pos2",    "<#FC5454><bold>\u2691 ᴘᴏs 2</bold> <gray>(sᴘᴀᴡɴ ʙ)", "ʀɪɢʜᴛ-ᴄʟɪᴄᴋ ᴛᴏ sᴇᴛ sᴘᴀᴡɴ ʙ"),
                tool(Material.YELLOW_DYE, "corner1", "<#FFD23C><bold>\u25A3 ᴄᴏʀɴᴇʀ 1</bold>", "ʀɪɢʜᴛ-ᴄʟɪᴄᴋ ᴛᴏ sᴇᴛ ᴄᴏʀɴᴇʀ 1"),
                tool(Material.ORANGE_DYE, "corner2", "<#FF8A3C><bold>\u25A3 ᴄᴏʀɴᴇʀ 2</bold>", "ʀɪɢʜᴛ-ᴄʟɪᴄᴋ ᴛᴏ sᴇᴛ ᴄᴏʀɴᴇʀ 2 (ᴇɴᴀʙʟᴇs ᴀʀᴇɴᴀ)"),
                tool(Material.NETHER_STAR, "lobby",  "<#5DC8FF><bold>\u2726 ʟᴏʙʙʏ sᴘᴀᴡɴ</bold>", "ʀɪɢʜᴛ-ᴄʟɪᴄᴋ ᴛᴏ sᴇᴛ ᴛʜᴇ ʟᴏʙʙʏ")
        );
    }

    private ItemStack tool(Material mat, String action, String name, String loreLine) {
        ItemStack it = new ItemStack(mat);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(plugin.msg().item(name));
        meta.lore(List.of(plugin.msg().item("<gray>" + loreLine)));
        meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, action);
        it.setItemMeta(meta);
        return it;
    }
}
