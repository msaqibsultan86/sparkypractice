package studio.spark.duels.util;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionType;
import studio.spark.duels.SparkDuels;

import java.util.Locale;
import java.util.Map;

/** Builds ItemStacks from kit config sections. */
public class ItemFactory {

    private final SparkDuels plugin;

    public ItemFactory(SparkDuels plugin) {
        this.plugin = plugin;
    }

    // Version-sensitive aliases: items added in newer 1.21.x fall back to a safe equivalent
    // on older servers, so kits/icons never break across 1.21 -> 1.21.11.
    private static final java.util.Map<String, String> ALIASES = new java.util.HashMap<>();
    static {
        ALIASES.put("NETHERITE_SPEAR", "NETHERITE_SWORD");
        ALIASES.put("DIAMOND_SPEAR",   "DIAMOND_SWORD");
        ALIASES.put("GOLDEN_SPEAR",    "GOLDEN_SWORD");
        ALIASES.put("IRON_SPEAR",      "IRON_SWORD");
        ALIASES.put("STONE_SPEAR",     "STONE_SWORD");
        ALIASES.put("COPPER_SPEAR",    "STONE_SWORD");
        ALIASES.put("WOODEN_SPEAR",    "WOODEN_SWORD");
    }

    public Material material(String name, Material fallback) {
        if (name == null) return fallback;
        String up = name.toUpperCase(Locale.ROOT);
        if (up.startsWith("MINECRAFT:")) up = up.substring(10);
        Material m = Material.matchMaterial(up);
        if (m != null) return m;
        String alias = ALIASES.get(up);          // try a version-safe equivalent
        if (alias != null) {
            Material am = Material.matchMaterial(alias);
            if (am != null) return am;
        }
        return fallback;
    }

    private Enchantment enchant(String name) {
        try {
            return Registry.ENCHANTMENT.get(NamespacedKey.minecraft(name.toLowerCase(Locale.ROOT)));
        } catch (Exception e) {
            return null;
        }
    }

    /** Build an item from a config section (type, amount, enchants, potion, name). */
    public ItemStack build(ConfigurationSection sec) {
        if (sec == null) return null;
        Material mat = material(sec.getString("type"), null);
        if (mat == null) return null;
        int amount = sec.getInt("amount", 1);
        ItemStack item = new ItemStack(mat, Math.max(1, amount));
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        ConfigurationSection ench = sec.getConfigurationSection("enchants");
        if (ench != null) {
            for (String key : ench.getKeys(false)) {
                Enchantment e = enchant(key);
                if (e != null) meta.addEnchant(e, ench.getInt(key), true);
            }
        }

        String potion = sec.getString("potion");
        if (potion != null && meta instanceof PotionMeta pm) {
            try {
                pm.setBasePotionType(PotionType.valueOf(potion.toUpperCase(Locale.ROOT)));
            } catch (IllegalArgumentException ignored) {}
        }

        String name = sec.getString("name");
        if (name != null) meta.displayName(plugin.msg().item(name));

        ConfigurationSection trim = sec.getConfigurationSection("trim");
        if (trim != null) applyTrim(meta, trim.getString("material"), trim.getString("pattern"));

        item.setItemMeta(meta);
        return item;
    }

    private void applyTrim(ItemMeta meta, String matName, String patName) {
        if (matName == null || patName == null) return;
        if (!(meta instanceof org.bukkit.inventory.meta.ArmorMeta am)) return;
        try {
            var tm = Registry.TRIM_MATERIAL.get(NamespacedKey.minecraft(matName.toLowerCase(Locale.ROOT)));
            var tp = Registry.TRIM_PATTERN.get(NamespacedKey.minecraft(patName.toLowerCase(Locale.ROOT)));
            if (tm != null && tp != null) am.setTrim(new org.bukkit.inventory.meta.trim.ArmorTrim(tm, tp));
        } catch (Exception ignored) {}
    }

    /** Build from a raw map (kit item lists come back as List<Map>). */
    @SuppressWarnings("unchecked")
    public ItemStack build(Map<?, ?> map) {
        if (map == null || map.get("type") == null) return null;
        Material mat = material(String.valueOf(map.get("type")), null);
        if (mat == null) return null;
        int amount = map.get("amount") instanceof Number num ? num.intValue() : 1;
        ItemStack item = new ItemStack(mat, Math.max(1, amount));
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        Object ench = map.get("enchants");
        if (ench instanceof Map<?, ?> em) {
            for (Map.Entry<?, ?> e : em.entrySet()) {
                Enchantment en = enchant(String.valueOf(e.getKey()));
                int lvl = e.getValue() instanceof Number num ? num.intValue() : 1;
                if (en != null) meta.addEnchant(en, lvl, true);
            }
        }
        Object potion = map.get("potion");
        if (potion != null && meta instanceof PotionMeta pm) {
            try { pm.setBasePotionType(PotionType.valueOf(String.valueOf(potion).toUpperCase(Locale.ROOT))); }
            catch (IllegalArgumentException ignored) {}
        }
        Object name = map.get("name");
        if (name != null) meta.displayName(plugin.msg().item(String.valueOf(name)));

        Object trim = map.get("trim");
        if (trim instanceof Map<?, ?> tmap) {
            applyTrim(meta, str(tmap.get("material")), str(tmap.get("pattern")));
        }

        item.setItemMeta(meta);
        return item;
    }

    private String str(Object o) { return o == null ? null : String.valueOf(o); }

    public int slotOf(Map<?, ?> map) {
        return map.get("slot") instanceof Number num ? num.intValue() : -1;
    }
}
