package studio.spark.duels.util;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import studio.spark.duels.SparkDuels;
import studio.spark.duels.stats.PlayerStats;

import java.util.HashMap;
import java.util.Map;

/** Resolves %placeholder% tokens for messages, scoreboards, lore. */
public class Placeholders {

    private final SparkDuels plugin;

    public Placeholders(SparkDuels plugin) {
        this.plugin = plugin;
    }

    public String apply(String text, Player p, Ctx ctx) {
        if (text == null || text.isEmpty()) return "";
        if (text.indexOf('%') < 0 && (ctx == null || ctx.values.isEmpty())) return text;

        Map<String, String> m = new HashMap<>();
        m.put("prefix", plugin.messages().getString("prefix", ""));
        m.put("server", Bukkit.getServer().getName());
        m.put("online", String.valueOf(Bukkit.getOnlinePlayers().size()));
        m.put("max_players", String.valueOf(Bukkit.getMaxPlayers()));
        m.put("plugin_version", plugin.getPluginMeta().getVersion());
        m.put("discord_link", plugin.getConfig().getString("discord-link", "discord.gg/sparkstudios"));
        m.put("modes_total", String.valueOf(plugin.modes().all().size()));
        m.put("arena_total", String.valueOf(plugin.arenas().all().size()));
        m.put("ffa_arena_total", String.valueOf(plugin.ffa() == null ? 0 : plugin.ffa().arenaCount()));
        int qTot = plugin.queue() == null ? 0 : plugin.queue().totalQueued();
        int mTot = plugin.matches() == null ? 0 : plugin.matches().totalInMatch();
        int fTot = plugin.ffa() == null ? 0 : plugin.ffa().totalInFfa();
        int onl = Bukkit.getOnlinePlayers().size();
        m.put("queued_total", String.valueOf(qTot));
        m.put("match_total", String.valueOf(mTot));
        m.put("ffa_total", String.valueOf(fTot));
        m.put("lobby_total", String.valueOf(Math.max(0, onl - qTot - mTot - fTot)));

        if (p != null) {
            m.put("player", p.getName());
            m.put("world", p.getWorld().getName());
            m.put("ping", String.valueOf(p.getPing()));
            PlayerStats s = plugin.stats().get(p.getUniqueId());
            m.put("wins", String.valueOf(s.wins));
            m.put("losses", String.valueOf(s.losses));
            m.put("kills", String.valueOf(s.kills));
            m.put("deaths", String.valueOf(s.deaths));
            m.put("streak", String.valueOf(s.streak));
            m.put("best_streak", String.valueOf(s.bestStreak));
            m.put("elo", String.valueOf(s.elo));
            m.put("coins", String.valueOf(s.coins));
            long _pt = s.playtime; long _h = _pt/60, _m = _pt%60;
            m.put("playtime", _h>0 ? (_h+"h "+_m+"m") : (_m+"m"));
            m.put("playtime_minutes", String.valueOf(s.playtime));
            m.put("kdr", String.format("%.2f", s.kdr()));
            m.put("winrate", String.valueOf(s.winrate()));
            m.put("matches_played", String.valueOf(s.wins + s.losses));
            m.put("ffa_kills", String.valueOf(s.ffaKills));
            m.put("ffa_deaths", String.valueOf(s.ffaDeaths));
            m.put("ffa_best_streak", String.valueOf(s.ffaBestStreak));
            m.put("ffa_kdr", String.format("%.2f", s.ffaKdr()));
            m.put("ffa_killstreak", String.valueOf(plugin.ffa() == null ? 0 : plugin.ffa().killstreakOf(p)));
            int rank = plugin.stats().rankOf(p.getUniqueId());
            m.put("rank", rank > 0 ? "#" + rank : "—");
        }

        if (ctx != null) m.putAll(ctx.values);

        StringBuilder out = new StringBuilder(text.length());
        int i = 0, n = text.length();
        while (i < n) {
            char c = text.charAt(i);
            if (c == '%') {
                int end = text.indexOf('%', i + 1);
                if (end > i) {
                    String key = text.substring(i + 1, end);
                    String val = m.get(key);
                    if (val != null) {
                        out.append(val);
                        i = end + 1;
                        continue;
                    }
                }
            }
            out.append(c);
            i++;
        }
        return out.toString();
    }
}
