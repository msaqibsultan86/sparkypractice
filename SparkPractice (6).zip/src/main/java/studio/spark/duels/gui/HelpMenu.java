package studio.spark.duels.gui;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import studio.spark.duels.SparkDuels;
import studio.spark.duels.util.Gui;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Clickable help menu — lists commands with details. Click an entry to run it. */
public class HelpMenu implements InventoryHolder {

    private final Map<Integer, String> slotCommand = new HashMap<>();
    private Inventory inventory;

    public Map<Integer, String> slotCommand() { return slotCommand; }

    @Override
    public Inventory getInventory() { return inventory; }

    /** One help entry: icon, title, command-to-run, usage line, description. */
    private record Entry(Material icon, String title, String command, String usage, String desc) {}

    public static void open(SparkDuels plugin, Player player) {
        HelpMenu menu = new HelpMenu();
        Inventory inv = Bukkit.createInventory(menu, 54,
                plugin.msg().parse("<gradient:#3CFF7E:#5DC8FF:#1F6FFF><bold>\u2694 sᴘᴀʀᴋ ᴘʀᴀᴄᴛɪᴄᴇ \u2022 ʜᴇʟᴘ</bold></gradient>"));
        menu.inventory = inv;

        Gui.border(inv, Gui.pane(Material.GRAY_STAINED_GLASS_PANE));
        Gui.corners(inv, Gui.pane(Material.LIME_STAINED_GLASS_PANE));

        // ---- player commands ----
        Entry[] playerCmds = {
            new Entry(Material.DIAMOND_SWORD,   "<gradient:#3CFF7E:#11A65B><bold>\u2694 ᴅᴜᴇʟ</bold></gradient>",
                    "duel", "/duel <player>", "ᴄʜᴀʟʟᴇɴɢᴇ ᴀ ᴘʟᴀʏᴇʀ ᴛᴏ ᴀ 1ᴠ1."),
            new Entry(Material.NETHERITE_SWORD, "<gradient:#FFD23C:#FF7A00><bold>\u2605 ǫᴜᴇᴜᴇ</bold></gradient>",
                    "queue", "/queue <mode>", "ᴊᴏɪɴ ʀᴀɴᴋᴇᴅ ᴏʀ ᴜɴʀᴀɴᴋᴇᴅ ᴍᴀᴛᴄʜᴍᴀᴋɪɴɢ."),
            new Entry(Material.IRON_AXE,        "<gradient:#FC5454:#A60000><bold>\u2620 ꜰꜰᴀ</bold></gradient>",
                    "ffa", "/ffa", "ᴏᴘᴇɴ ᴛʜᴇ ꜰʀᴇᴇ-ꜰᴏʀ-ᴀʟʟ ᴍᴇɴᴜ."),
            new Entry(Material.PLAYER_HEAD,     "<gradient:#C77DFF:#7F4FD6><bold>\uD83D\uDC65 ᴘᴀʀᴛʏ</bold></gradient>",
                    "party", "/party", "ᴄʀᴇᴀᴛᴇ ᴀ ᴘᴀʀᴛʏ, ɪɴᴠɪᴛᴇ ꜰʀɪᴇɴᴅs, 2ᴠ2."),
            new Entry(Material.BOOK,            "<gradient:#5DC8FF:#1F6FFF><bold>\uD83D\uDCCA sᴛᴀᴛs</bold></gradient>",
                    "stats", "/stats", "ᴠɪᴇᴡ ʏᴏᴜʀ ᴡɪɴs, ᴇʟᴏ, ᴋᴅʀ & sᴛʀᴇᴀᴋs."),
            new Entry(Material.ANVIL,           "<gradient:#5DC8FF:#1F6FFF><bold>\u270E ᴋɪᴛ ᴇᴅɪᴛᴏʀ</bold></gradient>",
                    "kiteditor", "/kiteditor", "ʙᴜɪʟᴅ ʏᴏᴜʀ ᴏᴡɴ ᴋɪᴛ ʟᴏᴀᴅᴏᴜᴛs."),
            new Entry(Material.GOLD_INGOT,      "<gradient:#FFD23C:#FF7A00><bold>\uD83C\uDFC6 ʟᴇᴀᴅᴇʀʙᴏᴀʀᴅ</bold></gradient>",
                    "leaderboard", "/leaderboard", "ᴛᴏᴘ ᴘʟᴀʏᴇʀs ʙʏ ᴇʟᴏ, ᴡɪɴs & ᴍᴏʀᴇ."),
            new Entry(Material.ENDER_EYE,       "<gradient:#3CFF7E:#11A65B><bold>\uD83D\uDC41 sᴘᴇᴄᴛᴀᴛᴇ</bold></gradient>",
                    "spectate", "/spectate <player>", "ᴡᴀᴛᴄʜ ᴀ ʟɪᴠᴇ ᴍᴀᴛᴄʜ."),
            new Entry(Material.RECOVERY_COMPASS,"<gradient:#FC5454:#A60000><bold>\u21BB ʀᴇᴍᴀᴛᴄʜ</bold></gradient>",
                    "rematch", "/rematch", "ʀᴇ-ᴄʜᴀʟʟᴇɴɢᴇ ʏᴏᴜʀ ʟᴀsᴛ ᴏᴘᴘᴏɴᴇɴᴛ.")
        };
        int[] playerSlots = {10, 11, 12, 13, 14, 15, 16, 19, 20};
        for (int i = 0; i < playerCmds.length && i < playerSlots.length; i++)
            place(plugin, inv, menu, playerSlots[i], playerCmds[i], "<#3CFF7E>");

        // ---- admin commands (only shown to admins) ----
        if (player.hasPermission("sparkpractice.admin")) {
            ItemStack label = Gui.pane(Material.RED_STAINED_GLASS_PANE);
            ItemMeta lm = label.getItemMeta();
            lm.displayName(plugin.msg().item("<gradient:#FC5454:#A60000><bold>\u2692 ᴀᴅᴍɪɴ ᴄᴏᴍᴍᴀɴᴅs</bold></gradient>"));
            label.setItemMeta(lm);
            inv.setItem(22, label);

            Entry[] adminCmds = {
                new Entry(Material.GRASS_BLOCK,        "<red><bold>sᴇᴛ ʟᴏʙʙʏ</bold></red>",
                        "setlobby", "/setlobby", "sᴇᴛ ᴛʜᴇ ʟᴏʙʙʏ sᴘᴀᴡɴ + ᴘʀᴏᴛᴇᴄᴛɪᴏɴ."),
                new Entry(Material.IRON_PICKAXE,       "<red><bold>ᴀʀᴇɴᴀ</bold></red>",
                        "arena", "/arena <create|list|delete>", "ᴍᴀɴᴀɢᴇ ᴅᴜᴇʟ ᴀʀᴇɴᴀs."),
                new Entry(Material.BLAZE_ROD,          "<red><bold>sᴇᴛᴜᴘ ᴛᴏᴏʟs</bold></red>",
                        "sptools", "/sptools", "ɢᴇᴛ ᴛʜᴇ ᴀʀᴇɴᴀ-sᴇᴛᴜᴘ ᴡᴀɴᴅ."),
                new Entry(Material.RED_BED,            "<red><bold>ꜰꜰᴀ ᴀʀᴇɴᴀ</bold></red>",
                        "ffarena", "/ffarena <create|addspawn|enable>", "sᴇᴛ ᴜᴘ ꜰꜰᴀ ᴀʀᴇɴᴀs."),
                new Entry(Material.VILLAGER_SPAWN_EGG, "<red><bold>ʟᴏʙʙʏ ɴᴘᴄs</bold></red>",
                        "spnpc", "/spnpc spawn <type>", "sᴘᴀᴡɴ ᴄʟɪᴄᴋᴀʙʟᴇ ʟᴏʙʙʏ ɴᴘᴄs."),
                new Entry(Material.CHEST,              "<red><bold>ᴋɪᴛ ᴇᴅɪᴛᴏʀ ᴀʀᴇᴀ</bold></red>",
                        "kiteditorarea", "/kiteditorarea build", "ʙᴜɪʟᴅ ᴛʜᴇ ᴋɪᴛ-ᴇᴅɪᴛᴏʀ ʀᴏᴏᴍ."),
                new Entry(Material.COMPARATOR,         "<red><bold>ᴍᴏᴅᴇ ᴋɪᴛ</bold></red>",
                        "modekit", "/modekit <mode> <kit>", "ʟɪɴᴋ ᴀ ᴋɪᴛ ᴛᴏ ᴀ ᴍᴏᴅᴇ."),
                new Entry(Material.REDSTONE,           "<red><bold>ʀᴇʟᴏᴀᴅ</bold></red>",
                        "sp reload", "/sp reload", "ʀᴇʟᴏᴀᴅ ᴀʟʟ ᴄᴏɴꜰɪɢs.")
            };
            int[] adminSlots = {28, 29, 30, 31, 32, 33, 34, 37};
            for (int i = 0; i < adminCmds.length && i < adminSlots.length; i++)
                place(plugin, inv, menu, adminSlots[i], adminCmds[i], "<#FC5454>");
        }

        // close button
        ItemStack close = new ItemStack(Material.BARRIER);
        ItemMeta cm = close.getItemMeta();
        cm.displayName(plugin.msg().item("<red><bold>\u2716 ᴄʟᴏsᴇ</bold></red>"));
        close.setItemMeta(cm);
        inv.setItem(49, close);
        menu.slotCommand.put(49, "__close__");

        Gui.fillEmpty(inv, Gui.pane(Material.BLACK_STAINED_GLASS_PANE));
        player.openInventory(inv);
        plugin.sounds().play(player, "gui-open");
    }

    private static void place(SparkDuels plugin, Inventory inv, HelpMenu menu, int slot, Entry e, String accent) {
        ItemStack item = new ItemStack(e.icon());
        ItemMeta meta = item.getItemMeta();
        meta.displayName(plugin.msg().item(e.title()));
        meta.lore(List.of(
                plugin.msg().item("<gray>" + e.desc()),
                plugin.msg().item("<dark_gray>" + e.usage()),
                plugin.msg().item(""),
                plugin.msg().item(accent + "\u25B6 ᴄʟɪᴄᴋ ᴛᴏ ʀᴜɴ")));
        item.setItemMeta(meta);
        inv.setItem(slot, item);
        menu.slotCommand.put(slot, e.command());
    }
}
