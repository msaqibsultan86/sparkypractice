package studio.spark.duels.nbt;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.GZIPInputStream;

/**
 * Minimal NBT reader — enough to parse Sponge .schem files. No external libraries.
 * Compounds -> Map<String,Object>, lists -> List<Object>, arrays -> byte[]/int[]/long[],
 * strings -> String, numbers -> boxed primitives.
 */
public final class Nbt {

    private Nbt() {}

    /** Read a (possibly gzipped) NBT file into a Map (the root compound). */
    @SuppressWarnings("unchecked")
    public static Map<String, Object> read(File file) throws IOException {
        InputStream in = new BufferedInputStream(new FileInputStream(file));
        // gzip magic 0x1f 0x8b
        in.mark(2);
        int b1 = in.read(), b2 = in.read();
        in.reset();
        if (b1 == 0x1f && b2 == 0x8b) in = new GZIPInputStream(in);
        try (DataInputStream dis = new DataInputStream(in)) {
            int type = dis.readUnsignedByte();
            if (type != 10) throw new IOException("Root tag is not a compound (got " + type + ")");
            dis.readUTF();                       // root name (usually "" or "Schematic")
            return (Map<String, Object>) readPayload(dis, 10);
        }
    }

    private static Object readPayload(DataInputStream in, int type) throws IOException {
        switch (type) {
            case 1:  return in.readByte();
            case 2:  return in.readShort();
            case 3:  return in.readInt();
            case 4:  return in.readLong();
            case 5:  return in.readFloat();
            case 6:  return in.readDouble();
            case 7: {                            // byte array
                int len = in.readInt();
                byte[] arr = new byte[len];
                in.readFully(arr);
                return arr;
            }
            case 8:  return in.readUTF();         // string
            case 9: {                             // list
                int itemType = in.readUnsignedByte();
                int len = in.readInt();
                List<Object> list = new ArrayList<>(Math.max(0, len));
                for (int i = 0; i < len; i++) list.add(readPayload(in, itemType));
                return list;
            }
            case 10: {                            // compound
                Map<String, Object> map = new LinkedHashMap<>();
                while (true) {
                    int t;
                    try { t = in.readUnsignedByte(); } catch (EOFException eof) { break; }
                    if (t == 0) break;            // TAG_End
                    String name = in.readUTF();
                    map.put(name, readPayload(in, t));
                }
                return map;
            }
            case 11: {                            // int array
                int len = in.readInt();
                int[] arr = new int[len];
                for (int i = 0; i < len; i++) arr[i] = in.readInt();
                return arr;
            }
            case 12: {                            // long array
                int len = in.readInt();
                long[] arr = new long[len];
                for (int i = 0; i < len; i++) arr[i] = in.readLong();
                return arr;
            }
            default: throw new IOException("Unknown NBT tag type: " + type);
        }
    }

    // ---- small typed getters (tolerant of Short/Int/Byte mixing) ----
    public static int getInt(Map<String, Object> m, String key, int def) {
        Object o = m.get(key);
        return o instanceof Number n ? n.intValue() : def;
    }
    @SuppressWarnings("unchecked")
    public static Map<String, Object> getMap(Map<String, Object> m, String key) {
        Object o = m.get(key);
        return o instanceof Map ? (Map<String, Object>) o : null;
    }
    public static byte[] getBytes(Map<String, Object> m, String key) {
        Object o = m.get(key);
        return o instanceof byte[] ? (byte[]) o : null;
    }
}
