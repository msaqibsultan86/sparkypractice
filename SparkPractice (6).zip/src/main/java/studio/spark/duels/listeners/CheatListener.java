package studio.spark.duels.listeners;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerAnimationEvent;
import org.bukkit.event.player.PlayerAnimationType;
import studio.spark.duels.SparkDuels;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Conservative, flag-first checks: reach, multi-target killaura, autoclicker CPS. */
public class CheatListener implements Listener {

    private final SparkDuels plugin;
    private final Map<UUID, Deque<Long>> clicks = new HashMap<>();
    private final Map<UUID, long[]> auraTick = new HashMap<>();   // [tickMs, lastVictimHash]

    public CheatListener(SparkDuels plugin) { this.plugin = plugin; }

    @EventHandler(ignoreCancelled = true)
    public void onAttack(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player attacker)) return;
        if (!(e.getEntity() instanceof Player victim)) return;
        CheatWatchAccess cw = new CheatWatchAccess(plugin);

        // ---- Reach (only meaningful while in a duel/ffa, survival) ----
        if (cw.check("reach")) {
            double max = cw.d("reach.max-distance", 4.0);
            double dist = attacker.getEyeLocation().distance(victim.getEyeLocation());
            if (dist > max) plugin.cheatWatch().flag(attacker, "Reach", String.format("%.2f", dist) + "b");
        }

        // ---- Multi-target killaura: 2+ distinct victims within ~120ms ----
        if (cw.check("killaura")) {
            long now = System.currentTimeMillis();
            long[] data = auraTick.get(attacker.getUniqueId());
            int vhash = victim.getUniqueId().hashCode();
            if (data != null && now - data[0] <= 120 && data[1] != vhash) {
                plugin.cheatWatch().flag(attacker, "KillAura", "multi-target");
            }
            auraTick.put(attacker.getUniqueId(), new long[]{now, vhash});
        }
    }

    @EventHandler
    public void onSwing(PlayerAnimationEvent e) {
        if (e.getAnimationType() != PlayerAnimationType.ARM_SWING) return;
        CheatWatchAccess cw = new CheatWatchAccess(plugin);
        if (!cw.check("autoclicker")) return;
        Player p = e.getPlayer();
        long now = System.currentTimeMillis();
        Deque<Long> dq = clicks.computeIfAbsent(p.getUniqueId(), k -> new ArrayDeque<>());
        dq.addLast(now);
        while (!dq.isEmpty() && now - dq.peekFirst() > 1000) dq.pollFirst();
        int cps = dq.size();
        if (cps > cw.i("autoclicker.max-cps", 22)) plugin.cheatWatch().flag(p, "AutoClicker", cps + " cps");
    }

    /** Tiny helper so this listener stays thin. */
    private record CheatWatchAccess(SparkDuels plugin) {
        boolean check(String n) { return plugin.cheatWatch().check(n); }
        double d(String p, double def) { return plugin.cheatWatch().d(p, def); }
        int i(String p, int def) { return plugin.cheatWatch().i(p, def); }
    }
}
