package studio.spark.duels.listeners;

import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Material;
import org.bukkit.GameMode;
import org.bukkit.entity.EnderPearl;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import studio.spark.duels.SparkDuels;

/** Ender-pearl cooldown + golden head, configurable in config.yml. */
public class CombatExtrasListener implements Listener {

    private final SparkDuels plugin;

    public CombatExtrasListener(SparkDuels plugin) { this.plugin = plugin; }

    @EventHandler
    public void onPearl(ProjectileLaunchEvent e) {
        if (!(e.getEntity() instanceof EnderPearl pearl)) return;
        if (!(pearl.getShooter() instanceof Player p)) return;
        if (p.getGameMode() == GameMode.CREATIVE) return;
        int secs = plugin.getConfig().getInt("combat.enderpearl-cooldown", 15);
        if (secs <= 0) return;
        p.setCooldown(Material.ENDER_PEARL, secs * 20);
    }

    @EventHandler
    public void onConsume(PlayerItemConsumeEvent e) {
        if (!plugin.getConfig().getBoolean("combat.golden-head.enabled", true)) return;
        ItemStack it = e.getItem();
        if (it == null || it.getType() != Material.GOLDEN_APPLE) return;
        if (!it.hasItemMeta() || it.getItemMeta().displayName() == null) return;
        String name = PlainTextComponentSerializer.plainText()
                .serialize(it.getItemMeta().displayName()).toLowerCase();
        if (!name.contains("head")) return;

        Player p = e.getPlayer();
        int absAmp = plugin.getConfig().getInt("combat.golden-head.absorption-amplifier", 1);
        int absSec = plugin.getConfig().getInt("combat.golden-head.absorption-seconds", 120);
        int regAmp = plugin.getConfig().getInt("combat.golden-head.regen-amplifier", 1);
        int regSec = plugin.getConfig().getInt("combat.golden-head.regen-seconds", 8);
        // apply next tick so it overrides the vanilla golden-apple effects
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            p.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, absSec * 20, absAmp, true, false));
            p.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, regSec * 20, regAmp, true, false));
        });
    }
}
