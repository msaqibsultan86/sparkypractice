package studio.spark.duels.listeners;

import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Color;
import org.bukkit.FireworkEffect;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerKickEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.persistence.PersistentDataType;
import studio.spark.duels.SparkDuels;
import studio.spark.duels.util.Ctx;

public class PlayerListener implements Listener {

    private final SparkDuels plugin;
    private final NamespacedKey joinedKey;

    public PlayerListener(SparkDuels plugin) {
        this.plugin = plugin;
        this.joinedKey = new NamespacedKey(plugin, "first_joined");
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        plugin.lobby().toLobby(p);

        // FIRST-TIME join only: rainbow firework
        var pdc = p.getPersistentDataContainer();
        if (!pdc.has(joinedKey, PersistentDataType.BYTE)) {
            pdc.set(joinedKey, PersistentDataType.BYTE, (byte) 1);
            if (plugin.getConfig().getBoolean("first-join.firework", true)) {
                plugin.getServer().getScheduler().runTaskLater(plugin, () -> rainbowFirework(p), 10L);
                plugin.msg().sendRaw(p, plugin.msg().prefix()
                        + "<rainbow>ᴡᴇʟᴄᴏᴍᴇ! ᴇɴᴊᴏʏ ʏᴏᴜʀ ꜰɪʀsᴛ ꜰɪɢʜᴛ.</rainbow>", Ctx.of());
            }
        }
    }

    private void rainbowFirework(Player p) {
        if (!p.isOnline()) return;
        Firework fw = p.getWorld().spawn(p.getLocation(), Firework.class);
        FireworkMeta meta = fw.getFireworkMeta();
        meta.addEffect(FireworkEffect.builder()
                .withColor(Color.RED, Color.ORANGE, Color.YELLOW, Color.LIME,
                        Color.AQUA, Color.BLUE, Color.FUCHSIA)
                .withFade(Color.WHITE)
                .with(FireworkEffect.Type.BALL_LARGE)
                .trail(true).flicker(true).build());
        meta.setPower(1);
        fw.setFireworkMeta(meta);
    }

    @EventHandler
    public void onKick(PlayerKickEvent e) {
        Player p = e.getPlayer();
        String reason = e.reason() == null ? ""
                : PlainTextComponentSerializer.plainText().serialize(e.reason());
        if (p.isBanned()) {
            plugin.hallOfShame().record(p.getName(), reason.isBlank() ? "Banned" : reason, "BAN");
        } else if (plugin.getConfig().getBoolean("hall-of-shame.log-kicks", false) && !reason.isBlank()) {
            plugin.hallOfShame().record(p.getName(), reason, "KICK");
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        var p = e.getPlayer();
        if (plugin.matches().isInMatch(p) && plugin.getConfig().getBoolean("match.combat-log-protection", true)) {
            plugin.matches().handleLeave(p);
        }
        if (plugin.teamMatches().isInTeamMatch(p)) plugin.teamMatches().handleLeave(p);
        plugin.queue().leaveSilent(p);
        plugin.ffa().leaveSilent(p);
        plugin.playerKitEditor().cancel(p);
        plugin.cheatWatch().clear(p);
        if (plugin.parties().inParty(p)) plugin.parties().leave(p);
        plugin.boards().remove(p);
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        if (plugin.lobby().hasSpawn()) e.setRespawnLocation(plugin.lobby().getSpawn());
        plugin.getServer().getScheduler().runTask(plugin, () -> plugin.lobby().toLobby(e.getPlayer()));
    }
}
