package studio.spark.duels.listeners;

import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.inventory.EquipmentSlot;
import studio.spark.duels.SparkDuels;

/** Handles clicks on /spnpc lobby NPCs and keeps them unkillable. */
public class LobbyNpcListener implements Listener {

    private final SparkDuels plugin;

    public LobbyNpcListener(SparkDuels plugin) { this.plugin = plugin; }

    // Right-click → run action (ignore off-hand so it fires once)
    @EventHandler
    public void onRightClick(PlayerInteractEntityEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        Entity ent = e.getRightClicked();
        if (plugin.lobbyNpcs().isNpc(ent)) {
            e.setCancelled(true);
            plugin.lobbyNpcs().run(plugin.lobbyNpcs().typeOf(ent), e.getPlayer());
        }
    }

    // Left-click (attack) → run action + unkillable
    @EventHandler
    public void onLeftClick(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player p)) return;
        Entity ent = e.getEntity();
        if (plugin.lobbyNpcs().isNpc(ent)) {
            e.setCancelled(true);
            plugin.lobbyNpcs().run(plugin.lobbyNpcs().typeOf(ent), p);
        }
    }

    // Block all other damage (fire, splash, etc.)
    @EventHandler
    public void onAnyDamage(EntityDamageEvent e) {
        if (plugin.lobbyNpcs().isNpc(e.getEntity())) e.setCancelled(true);
    }
}
