package studio.spark.duels.listeners;

import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import studio.spark.duels.SparkDuels;

public class KitEditorListener implements Listener {

    private final SparkDuels plugin;

    public KitEditorListener(SparkDuels plugin) { this.plugin = plugin; }

    /** Runs the NPC's action (save, leave, or open kit menu) for a player. */
    private boolean trigger(Entity clicked, Player p) {
        if (plugin.playerKitEditor().isNpc(clicked)) {
            if (plugin.playerKitEditor().isEditing(p)) plugin.playerKitEditor().save(p);
            else plugin.playerKitEditor().openMenu(p);
            return true;
        }
        if (plugin.playerKitEditor().isLeaveNpc(clicked)) {
            plugin.playerKitEditor().leave(p);
            return true;
        }
        if (plugin.playerKitEditor().isMenuNpc(clicked)) {
            plugin.playerKitEditor().openKitMenu(p);
            return true;
        }
        return false;
    }

    // Right-click on the NPC
    @EventHandler
    public void onRightClickNpc(PlayerInteractEntityEvent e) {
        if (trigger(e.getRightClicked(), e.getPlayer())) e.setCancelled(true);
    }

    // Left-click (attack) on the NPC — also triggers it, and makes the NPC unkillable
    @EventHandler
    public void onLeftClickNpc(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player p)) return;
        Entity ent = e.getEntity();
        if (plugin.playerKitEditor().isNpc(ent) || plugin.playerKitEditor().isLeaveNpc(ent)
                || plugin.playerKitEditor().isMenuNpc(ent)) {
            e.setCancelled(true);   // unkillable
            trigger(ent, p);
        }
    }

    // Belt-and-braces: block ALL damage to the NPCs (fire, splash, etc.)
    @EventHandler
    public void onAnyDamage(EntityDamageEvent e) {
        Entity ent = e.getEntity();
        if (plugin.playerKitEditor().isNpc(ent) || plugin.playerKitEditor().isLeaveNpc(ent)
                || plugin.playerKitEditor().isMenuNpc(ent))
            e.setCancelled(true);
    }

    @EventHandler
    public void onBreak(BlockBreakEvent e) {
        if (plugin.playerKitEditor().isEditing(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler
    public void onPlace(BlockPlaceEvent e) {
        if (plugin.playerKitEditor().isEditing(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent e) {
        if (plugin.playerKitEditor().isEditing(e.getPlayer())) e.setCancelled(true);
    }
}
