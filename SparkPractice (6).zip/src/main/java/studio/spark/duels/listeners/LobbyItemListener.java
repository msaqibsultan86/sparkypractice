package studio.spark.duels.listeners;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import studio.spark.duels.SparkDuels;
import studio.spark.duels.gui.FFAMenu;
import studio.spark.duels.gui.LeaderboardMenu;
import studio.spark.duels.gui.PartyMenu;
import studio.spark.duels.gui.QueueMenu;
import studio.spark.duels.model.Mode;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class LobbyItemListener implements Listener {

    private final SparkDuels plugin;

    /** Per-player cooldown (epoch millis) blocking lobby-item right-clicks. */
    private final Map<UUID, Long> cooldown = new HashMap<>();

    /** How long to block clicks after a context change (leaving party/queue). */
    private static final long CONTEXT_COOLDOWN_MS = 2000L;

    public LobbyItemListener(SparkDuels plugin) { this.plugin = plugin; }

    /** Start a cooldown so the slot that just changed can't be re-clicked by accident. */
    public void cooldown(Player p, long ms) {
        cooldown.put(p.getUniqueId(), System.currentTimeMillis() + ms);
    }

    private boolean onCooldown(Player p) {
        Long until = cooldown.get(p.getUniqueId());
        if (until == null) return false;
        if (System.currentTimeMillis() >= until) { cooldown.remove(p.getUniqueId()); return false; }
        return true;
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        // Ignore the off-hand duplicate event so a single right-click fires once.
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;

        Player p = e.getPlayer();
        String action = plugin.lobbyItems().actionOf(e.getItem());
        if (action == null) return;
        e.setCancelled(true);

        // Swallow clicks during the post-leave cooldown so the new slot item
        // (e.g. the leaderboard that lands where "leave party" was) doesn't open.
        if (onCooldown(p)) return;

        switch (action) {
            case "q:u" -> QueueMenu.open(plugin, p, false);
            case "q:r" -> QueueMenu.open(plugin, p, true);
            case "ffa" -> FFAMenu.open(plugin, p);
            case "top" -> LeaderboardMenu.open(plugin, p, false);
            case "leave-queue" -> { plugin.queue().leave(p, true); cooldown(p, CONTEXT_COOLDOWN_MS); }
            case "party" -> {
                if (plugin.parties().inParty(p)) PartyMenu.open(plugin, p);
                else { plugin.parties().create(p); plugin.lobbyItems().give(p); }
            }
            case "p:menu" -> PartyMenu.open(plugin, p);
            case "p:duel" -> plugin.parties().startDuel(p, firstDuel());
            case "p:ffa" -> plugin.parties().startFfa(p, firstFfa());
            case "p:leave" -> { plugin.parties().leave(p); plugin.lobbyItems().give(p); cooldown(p, CONTEXT_COOLDOWN_MS); }
            default -> { }
        }
    }

    private String firstDuel() {
        return plugin.modes().duelModes().stream().findFirst().map(Mode::id).orElse("");
    }

    private String firstFfa() {
        return plugin.modes().all().stream().filter(Mode::ffa).findFirst().map(Mode::id).orElse("");
    }
}
