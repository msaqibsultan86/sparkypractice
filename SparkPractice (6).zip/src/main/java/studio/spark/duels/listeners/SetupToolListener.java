package studio.spark.duels.listeners;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import studio.spark.duels.SparkDuels;
import studio.spark.duels.arena.Arena;
import studio.spark.duels.util.Ctx;

public class SetupToolListener implements Listener {

    private final SparkDuels plugin;

    public SetupToolListener(SparkDuels plugin) { this.plugin = plugin; }

    @EventHandler
    public void onUse(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        if (e.getAction() != Action.RIGHT_CLICK_AIR && e.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        String action = plugin.setupTools().actionOf(e.getItem());
        if (action == null) return;
        e.setCancelled(true);

        Player p = e.getPlayer();
        if (!p.hasPermission("sparkpractice.arena")) { plugin.msg().send(p, "general.no-permission"); return; }

        if (action.equals("lobby")) {
            plugin.lobby().setSpawn(p.getLocation());
            plugin.msg().sendRaw(p, plugin.msg().prefix() + "<#5DC8FF>ʟᴏʙʙʏ sᴘᴀᴡɴ sᴇᴛ.", Ctx.of());
            plugin.sounds().play(p, "click");
            return;
        }

        Arena ar = plugin.arenas().currentSetup(p.getUniqueId());
        if (ar == null) {
            plugin.msg().sendRaw(p, plugin.msg().prefix() + "<red>✖ ᴄʀᴇᴀᴛᴇ/sᴇʟᴇᴄᴛ ᴀɴ ᴀʀᴇɴᴀ ꜰɪʀsᴛ <gray>(/arena create <name>)", Ctx.of());
            return;
        }
        switch (action) {
            case "pos1" -> { ar.spawn1(p.getLocation()); plugin.msg().send(p, "arena.pos1-set"); }
            case "pos2" -> { ar.spawn2(p.getLocation()); plugin.msg().send(p, "arena.pos2-set"); }
            case "corner1" -> { ar.corner1(p.getLocation()); plugin.msg().send(p, "arena.corner1-set"); }
            case "corner2" -> {
                ar.corner2(p.getLocation());
                ar.enabled(true);
                plugin.msg().send(p, "arena.corner2-set", Ctx.of().put("arena", ar.name()));
            }
        }
        plugin.arenas().save();
        plugin.sounds().play(p, "click");
    }
}
