package studio.spark.duels.leaderboard;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.persistence.PersistentDataType;
import studio.spark.duels.SparkDuels;
import studio.spark.duels.stats.PlayerStats;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Floating leaderboard holograms using native 1.19.4+ TextDisplay entities.
 * No external hologram plugin (DecentHolograms / AJLeaderboards) required.
 */
public class LeaderboardHologram {

    public static final List<String> TYPES =
            Arrays.asList("KILLS", "DEATHS", "PLAYTIME", "ELO", "WINS", "LOSSES");

    private final SparkDuels plugin;
    private final File file;
    private final NamespacedKey tagKey;
    private final List<Holo> holos = new ArrayList<>();

    public LeaderboardHologram(SparkDuels plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "holograms.yml");
        this.tagKey = new NamespacedKey(plugin, "lb_type");
    }

    private record Holo(String type, Location loc, UUID entity) {}

    public boolean isValidType(String t) {
        return t != null && TYPES.contains(t.toUpperCase(java.util.Locale.ROOT));
    }

    /** Summon a leaderboard hologram at the player's location. */
    public boolean summon(Player p, String type) {
        if (!isValidType(type)) return false;
        type = type.toUpperCase(java.util.Locale.ROOT);
        Location loc = p.getLocation().clone();
        loc.add(0, 2.3, 0);
        loc.setPitch(0);
        TextDisplay td = spawn(loc, type);
        holos.add(new Holo(type, loc, td.getUniqueId()));
        save();
        return true;
    }

    /** Remove the nearest hologram within 6 blocks of the player. */
    public boolean removeNearest(Player p) {
        Holo best = null;
        double bestD = 36.0; // 6 blocks squared
        for (Holo h : holos) {
            if (!h.loc().getWorld().equals(p.getWorld())) continue;
            double d = h.loc().distanceSquared(p.getLocation());
            if (d <= bestD) { bestD = d; best = h; }
        }
        if (best == null) return false;
        Entity e = Bukkit.getEntity(best.entity());
        if (e != null) e.remove();
        holos.remove(best);
        save();
        return true;
    }

    public int count() { return holos.size(); }

    public List<String> listLines() {
        List<String> out = new ArrayList<>();
        for (Holo h : holos) {
            Location l = h.loc();
            out.add(h.type() + " @ " + l.getWorld().getName()
                    + " " + (int) l.getX() + "," + (int) l.getY() + "," + (int) l.getZ());
        }
        return out;
    }

    /** Refresh the text of all holograms from current stats. */
    public void update() {
        for (Holo h : holos) {
            Entity e = Bukkit.getEntity(h.entity());
            if (e instanceof TextDisplay td) td.text(buildText(h.type()));
        }
    }

    // ---- spawn / build ----

    private TextDisplay spawn(Location loc, String type) {
        World w = loc.getWorld();
        return w.spawn(loc, TextDisplay.class, td -> {
            td.text(buildText(type));
            td.setBillboard(Display.Billboard.CENTER);
            td.setAlignment(TextDisplay.TextAlignment.CENTER);
            td.setShadowed(true);
            td.setSeeThrough(false);
            td.setBackgroundColor(Color.fromARGB(140, 0, 0, 0));
            td.setPersistent(true);
            td.getPersistentDataContainer().set(tagKey, PersistentDataType.STRING, type);
        });
    }

    private Component buildText(String type) {
        StringBuilder sb = new StringBuilder();
        sb.append("<gradient:#3CFF7E:#11A65B><bold>").append(icon(type)).append(" ")
          .append(title(type)).append("</bold></gradient>");
        List<Map.Entry<UUID, PlayerStats>> top = plugin.stats().topByStat(type, 10);
        int rank = 1;
        for (Map.Entry<UUID, PlayerStats> e : top) {
            long v = plugin.stats().statValue(e.getValue(), type);
            String name = plugin.stats().nameOf(e.getKey());
            String medal = switch (rank) {
                case 1 -> "<#FFD23C>";
                case 2 -> "<#C0C0C0>";
                case 3 -> "<#CD7F32>";
                default -> "<gray>";
            };
            sb.append("<newline>").append(medal).append("#").append(rank)
              .append(" <white>").append(escape(name))
              .append(" <dark_gray>- <#3CFF7E>").append(format(type, v));
            rank++;
        }
        if (top.isEmpty()) sb.append("<newline><gray>No data yet");
        return plugin.msg().parse(sb.toString());
    }

    private String escape(String s) { return s == null ? "?" : s.replace("<", "").replace(">", ""); }

    private String icon(String t) {
        return switch (t) {
            case "KILLS" -> "\u2694";   // crossed swords
            case "DEATHS" -> "\u2620";  // skull & crossbones
            case "PLAYTIME" -> "\u23F1";// stopwatch
            case "ELO" -> "\u2605";     // star
            case "WINS" -> "\u2191";    // up arrow
            case "LOSSES" -> "\u2193";  // down arrow
            default -> "\u2756";
        };
    }

    private String title(String t) {
        return switch (t) {
            case "KILLS" -> "TOP KILLS";
            case "DEATHS" -> "TOP DEATHS";
            case "PLAYTIME" -> "TOP PLAYTIME";
            case "ELO" -> "TOP ELO";
            case "WINS" -> "TOP WINS";
            case "LOSSES" -> "TOP LOSSES";
            default -> "TOP";
        };
    }

    private String format(String type, long v) {
        if (type.equals("PLAYTIME")) {
            long h = v / 60, m = v % 60;
            if (h >= 24) { long d = h / 24; h = h % 24; return d + "d " + h + "h"; }
            return h > 0 ? h + "h " + m + "m" : m + "m";
        }
        return String.valueOf(v);
    }

    // ---- persistence ----

    /** Despawn any leftover tagged displays in loaded worlds, then spawn from config. */
    public void load() {
        // cleanup orphans so a restart never stacks duplicates
        for (World w : Bukkit.getWorlds()) {
            for (Entity e : w.getEntities()) {
                if (e instanceof TextDisplay
                        && e.getPersistentDataContainer().has(tagKey, PersistentDataType.STRING)) {
                    e.remove();
                }
            }
        }
        holos.clear();
        if (!file.exists()) return;
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection root = cfg.getConfigurationSection("holograms");
        if (root == null) return;
        for (String key : root.getKeys(false)) {
            ConfigurationSection s = root.getConfigurationSection(key);
            if (s == null) continue;
            String type = s.getString("type", "");
            if (!isValidType(type)) continue;
            World w = Bukkit.getWorld(s.getString("world", ""));
            if (w == null) continue;
            Location loc = new Location(w, s.getDouble("x"), s.getDouble("y"), s.getDouble("z"));
            TextDisplay td = spawn(loc, type.toUpperCase(java.util.Locale.ROOT));
            holos.add(new Holo(type.toUpperCase(java.util.Locale.ROOT), loc, td.getUniqueId()));
        }
        plugin.getLogger().info("Loaded " + holos.size() + " leaderboard hologram(s).");
    }

    public void save() {
        YamlConfiguration cfg = new YamlConfiguration();
        ConfigurationSection root = cfg.createSection("holograms");
        int i = 0;
        for (Holo h : holos) {
            ConfigurationSection s = root.createSection("h" + (i++));
            s.set("type", h.type());
            s.set("world", h.loc().getWorld().getName());
            s.set("x", h.loc().getX());
            s.set("y", h.loc().getY());
            s.set("z", h.loc().getZ());
        }
        try {
            if (!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs();
            cfg.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("Could not save holograms.yml: " + e.getMessage());
        }
    }

    /** On disable: persist positions and remove the entities (re-spawned on next load). */
    public void saveAndDespawn() {
        save();
        for (Holo h : holos) {
            Entity e = Bukkit.getEntity(h.entity());
            if (e != null) e.remove();
        }
    }
}
