package studio.spark.duels.shame;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.persistence.PersistentDataType;
import studio.spark.duels.SparkDuels;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** A "Hall of Shame" board listing recently banned / kicked players + reason. */
public class HallOfShame {

    private final SparkDuels plugin;
    private final File file;
    private final NamespacedKey tagKey;
    private final List<Entry> entries = new ArrayList<>();
    private Location holoLoc;
    private UUID holoEntity;

    private static final int MAX_ENTRIES = 40;
    private static final int SHOWN = 12;

    public HallOfShame(SparkDuels plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "hallofshame.yml");
        this.tagKey = new NamespacedKey(plugin, "shame_holo");
    }

    private record Entry(String name, String reason, String type, long time) {}

    /** Add a shame entry (BAN / KICK) and refresh the board. */
    public void record(String name, String reason, String type) {
        if (name == null) return;
        entries.add(0, new Entry(name, reason == null ? "?" : reason, type, System.currentTimeMillis()));
        while (entries.size() > MAX_ENTRIES) entries.remove(entries.size() - 1);
        save();
        update();
    }

    public void clear() { entries.clear(); save(); update(); }
    public int size() { return entries.size(); }

    // ---- hologram ----
    public boolean summon(Player p) {
        holoLoc = p.getLocation().clone();
        holoLoc.add(0, 2.3, 0);
        holoLoc.setPitch(0);
        spawn();
        save();
        return true;
    }

    public boolean remove() {
        if (holoEntity != null) {
            Entity e = Bukkit.getEntity(holoEntity);
            if (e != null) e.remove();
        }
        holoEntity = null;
        holoLoc = null;
        save();
        return true;
    }

    public void update() {
        if (holoEntity == null) return;
        Entity e = Bukkit.getEntity(holoEntity);
        if (e instanceof TextDisplay td) td.text(buildText());
    }

    private void spawn() {
        if (holoLoc == null || holoLoc.getWorld() == null) return;
        if (holoEntity != null) {
            Entity old = Bukkit.getEntity(holoEntity);
            if (old != null) old.remove();
        }
        TextDisplay td = holoLoc.getWorld().spawn(holoLoc, TextDisplay.class, d -> {
            d.text(buildText());
            d.setBillboard(Display.Billboard.CENTER);
            d.setAlignment(TextDisplay.TextAlignment.CENTER);
            d.setShadowed(true);
            d.setSeeThrough(false);
            d.setBackgroundColor(Color.fromARGB(150, 20, 0, 0));
            d.setPersistent(true);
            d.getPersistentDataContainer().set(tagKey, PersistentDataType.STRING, "shame");
        });
        holoEntity = td.getUniqueId();
    }

    private Component buildText() {
        StringBuilder sb = new StringBuilder();
        sb.append("<gradient:#FC5454:#A60000><bold>\u2620 ʜᴀʟʟ ᴏꜰ sʜᴀᴍᴇ</bold></gradient>");
        if (entries.isEmpty()) {
            sb.append("<newline><gray>ɴᴏ ᴄʜᴇᴀᴛᴇʀs ʏᴇᴛ. ᴋᴇᴇᴘ ɪᴛ ᴄʟᴇᴀɴ.");
        } else {
            int n = 0;
            for (Entry e : entries) {
                if (n++ >= SHOWN) break;
                String tag = e.type().equals("BAN") ? "<#FC5454>ʙᴀɴ" : "<#FFD23C>ᴋɪᴄᴋ";
                sb.append("<newline>").append(tag).append(" <white>").append(escape(e.name()))
                  .append(" <dark_gray>- <gray>").append(escape(e.reason()));
            }
        }
        return plugin.msg().parse(sb.toString());
    }

    private String escape(String s) { return s == null ? "?" : s.replace("<", "").replace(">", ""); }

    // ---- persistence ----
    public void load() {
        for (World w : Bukkit.getWorlds())
            for (Entity e : w.getEntities())
                if (e instanceof TextDisplay
                        && e.getPersistentDataContainer().has(tagKey, PersistentDataType.STRING))
                    e.remove();
        entries.clear();
        holoEntity = null; holoLoc = null;
        if (!file.exists()) return;
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        List<?> raw = cfg.getList("entries");
        if (raw != null) {
            for (Object o : raw) {
                if (o instanceof java.util.Map<?, ?> m) {
                    entries.add(new Entry(
                            String.valueOf(m.get("name")),
                            String.valueOf(m.get("reason")),
                            String.valueOf(m.get("type")),
                            m.get("time") instanceof Number num ? num.longValue() : 0L));
                }
            }
        }
        ConfigurationSection h = cfg.getConfigurationSection("hologram");
        if (h != null) {
            World w = Bukkit.getWorld(h.getString("world", ""));
            if (w != null) {
                holoLoc = new Location(w, h.getDouble("x"), h.getDouble("y"), h.getDouble("z"));
                spawn();
            }
        }
    }

    public void save() {
        YamlConfiguration cfg = new YamlConfiguration();
        List<java.util.Map<String, Object>> raw = new ArrayList<>();
        for (Entry e : entries) {
            java.util.Map<String, Object> m = new java.util.HashMap<>();
            m.put("name", e.name());
            m.put("reason", e.reason());
            m.put("type", e.type());
            m.put("time", e.time());
            raw.add(m);
        }
        cfg.set("entries", raw);
        if (holoLoc != null) {
            cfg.set("hologram.world", holoLoc.getWorld().getName());
            cfg.set("hologram.x", holoLoc.getX());
            cfg.set("hologram.y", holoLoc.getY());
            cfg.set("hologram.z", holoLoc.getZ());
        }
        try {
            if (!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs();
            cfg.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("Could not save hallofshame.yml: " + e.getMessage());
        }
    }

    public void saveAndDespawn() {
        save();
        if (holoEntity != null) {
            Entity e = Bukkit.getEntity(holoEntity);
            if (e != null) e.remove();
        }
    }
}
