package studio.spark.duels.spectate;

import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import studio.spark.duels.SparkDuels;
import studio.spark.duels.match.Match;
import studio.spark.duels.util.Ctx;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Lightweight spectator system: watch a player's live fight in spectator mode. */
public class SpectatorManager {

    private final SparkDuels plugin;
    private final Map<UUID, UUID> watching = new HashMap<>(); // spectator -> target

    public SpectatorManager(SparkDuels plugin) { this.plugin = plugin; }

    public boolean isSpectating(Player p) { return watching.containsKey(p.getUniqueId()); }

    public void spectate(Player p, Player target) {
        if (target == null || !target.isOnline()) { plugin.msg().send(p, "spectate.no-target"); return; }
        if (plugin.matches().isInMatch(p) || plugin.ffa().isInFfa(p) || plugin.queue().isQueued(p)) {
            plugin.msg().send(p, "spectate.busy"); return;
        }
        Match m = plugin.matches().getMatch(target);
        if (m == null) { plugin.msg().send(p, "spectate.not-fighting", Ctx.of().target(target)); return; }

        watching.put(p.getUniqueId(), target.getUniqueId());
        p.setGameMode(GameMode.SPECTATOR);
        p.teleport(target.getLocation());
        plugin.msg().send(p, "spectate.now-watching", Ctx.of().target(target));
        plugin.sounds().play(p, "gui-open");
    }

    public void leave(Player p) {
        if (watching.remove(p.getUniqueId()) == null) return;
        plugin.lobby().toLobby(p); // restores survival + lobby spawn
        plugin.msg().send(p, "spectate.stopped");
    }

    /** Returns spectators to the lobby once the fight they watch is over. */
    public void tick() {
        if (watching.isEmpty()) return;
        for (UUID specId : new HashMap<>(watching).keySet()) {
            Player spec = plugin.getServer().getPlayer(specId);
            if (spec == null) { watching.remove(specId); continue; }
            UUID targetId = watching.get(specId);
            Player target = plugin.getServer().getPlayer(targetId);
            if (target == null || !plugin.matches().isInMatch(target)) leave(spec);
        }
    }
}
